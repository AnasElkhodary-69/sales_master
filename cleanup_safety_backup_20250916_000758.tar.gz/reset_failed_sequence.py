#!/usr/bin/env python3
"""
Reset failed sequence back to scheduled so it can be processed again
"""

import os
import sys
from datetime import datetime, timedelta

# Add the app directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from models.database import db, EmailSequence

def reset_failed_sequence():
    """Reset failed sequences back to scheduled"""
    print("=" * 60)
    print("RESETTING FAILED SEQUENCES")
    print("=" * 60)

    app = create_app()
    with app.app_context():
        # Find failed sequences
        failed_sequences = EmailSequence.query.filter_by(status='failed').all()

        print(f"Found {len(failed_sequences)} failed sequences")

        for seq in failed_sequences:
            contact = seq.contact
            print(f"Resetting sequence {seq.id}: Contact {contact.email} - Step {seq.sequence_step}")

            # Reset to scheduled and update timing to now
            seq.status = 'scheduled'
            seq.scheduled_datetime = datetime.utcnow()  # Make it immediately available
            seq.scheduled_date = datetime.utcnow().date()

            print(f"  Status: failed -> scheduled")
            print(f"  Scheduled: {seq.scheduled_datetime}")

        db.session.commit()
        print("\n✅ Failed sequences reset to scheduled!")

        # Show current state
        print("\n📅 CURRENT EMAIL SEQUENCES:")
        all_sequences = EmailSequence.query.order_by(
            EmailSequence.contact_id,
            EmailSequence.sequence_step
        ).all()

        for seq in all_sequences:
            contact = seq.contact
            if contact:
                status_icon = "⏰" if seq.status == "scheduled" else "✅" if seq.status == "sent" else "❌"
                time_str = seq.scheduled_datetime.strftime("%H:%M:%S") if seq.scheduled_datetime else "N/A"
                print(f"  {status_icon} {contact.email} - Step {seq.sequence_step} - {time_str} - {seq.status}")

if __name__ == "__main__":
    reset_failed_sequence()