"""
SalesBreachPro Application Factory
Clean, modular Flask application setup
"""
import os
from flask import Flask
from dotenv import load_dotenv

# Import database models
from models.database import (
    db, Contact, Campaign, Breach, Email, Response, 
    EmailTemplate, FollowUpSequence, Settings, WebhookEvent
)

# Import blueprints
from routes.auth import auth_bp
from routes.dashboard import dashboard_bp
from routes.campaigns import campaigns_bp
from routes.contacts import contacts_bp
from routes.api import api_bp
from routes.analytics import analytics_bp
from routes.tracking import tracking_bp
from routes.sequences import sequences_bp
from routes.templates import templates_bp
from routes.scan_progress import scan_progress_bp
from routes.webhooks import webhooks_bp
from routes.email_trigger import email_trigger_bp
from routes.enhanced_analytics import enhanced_analytics_bp
from routes.flawtrack_admin import flawtrack_admin_bp
from routes.breach_checker import breach_checker_bp

# Import service routes
from services.template_routes import register_template_routes


def create_app():
    """Create and configure Flask application"""
    app = Flask(__name__)
    
    # Load environment variables from env file
    basedir = os.path.abspath(os.path.dirname(__file__))
    
    # Try .env first (standard), then env (custom)
    env_files = ['.env', 'env']
    loaded = False
    
    for env_filename in env_files:
        env_file = os.path.join(basedir, env_filename)
        if os.path.exists(env_file):
            load_dotenv(env_file)
            print(f"Loaded environment variables from: {env_file}")
            
            # Show FlawTrack API status
            api_token = os.getenv('FLAWTRACK_API_TOKEN')
            endpoint = os.getenv('FLAWTRACK_API_ENDPOINT')
            if api_token and endpoint and not api_token.startswith('your-'):
                print(f"[OK] FlawTrack API v2.0 configured (token: {api_token[:12]}...)")
                print(f"    Endpoint: {endpoint}")
            else:
                print(f"[!] FlawTrack API v2.0 configuration incomplete")
            
            loaded = True
            break
    
    if not loaded:
        print(f"Warning: No environment file found (.env or env)")
    
    # Configuration
    app.config['SECRET_KEY'] = 'dev-secret-key-change-in-production'
    app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{os.path.join(basedir, "data", "app.db")}'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
        'pool_pre_ping': True,
        'pool_recycle': -1,
        'echo': False
    }
    
    # Admin credentials
    app.config['ADMIN_USERNAME'] = 'admin'
    app.config['ADMIN_PASSWORD'] = 'SalesBreachPro2025!'
    
    # Initialize database
    db.init_app(app)
    
    # Register core blueprints with consistent URL patterns
    app.register_blueprint(auth_bp)                    # No prefix - root routes
    app.register_blueprint(dashboard_bp)               # No prefix - /dashboard, /settings
    app.register_blueprint(campaigns_bp)               # /campaigns/*
    app.register_blueprint(contacts_bp)                # /contacts/*
    app.register_blueprint(templates_bp)               # /templates/*
    app.register_blueprint(sequences_bp)               # /admin/sequences/*
    app.register_blueprint(analytics_bp)               # /analytics/*
    app.register_blueprint(tracking_bp)                # /track/*, /unsubscribe/*
    
    # Register API blueprints
    app.register_blueprint(api_bp)                     # /api/*
    app.register_blueprint(scan_progress_bp)           # /api/scan/*
    app.register_blueprint(webhooks_bp)                # /webhooks/*
    app.register_blueprint(email_trigger_bp)           # /api/trigger-emails
    app.register_blueprint(enhanced_analytics_bp)      # /sequence-analytics, /api/sequence-*
    app.register_blueprint(flawtrack_admin_bp)         # /admin/flawtrack/*
    app.register_blueprint(breach_checker_bp)          # /breach-checker
    
    print("All blueprints registered successfully!")

    # Register service routes
    try:
        register_template_routes(app)
        print("Template service routes registered successfully!")
    except Exception as e:
        print(f"Warning: Could not register template routes: {e}")

    # Legacy route support for backward compatibility
    try:
        from services.contact_routes import init_contact_routes
        init_contact_routes(app)
        print("Legacy contact routes initialized successfully!")
    except Exception as e:
        print(f"Warning: Legacy contact routes not initialized: {e}")
    
    # Initialize database tables
    with app.app_context():
        try:
            db.create_all()
            print("Database tables created successfully!")
        except Exception as e:
            print(f"Database error: {e}")
    
    # Initialize background scheduler for auto-enrollment
    try:
        from services.scheduler import init_scheduler
        init_scheduler(app, db)
        print("Background scheduler initialized successfully!")
    except Exception as e:
        print(f"Scheduler initialization warning: {e}")
        print("Auto-enrollment will not work automatically, but can be triggered manually")

    # Initialize FlawTrack API health monitoring
    try:
        from services.flawtrack_monitor import start_monitoring
        monitoring_started = start_monitoring()
        if monitoring_started:
            print("FlawTrack API health monitoring started successfully!")
        else:
            print("Warning: FlawTrack API health monitoring failed to start")
    except Exception as e:
        print(f"FlawTrack monitoring initialization warning: {e}")
        print("API health monitoring will not be available")
    
    # Add error handlers for better production deployment
    @app.errorhandler(404)
    def not_found_error(error):
        return f"<h1>404 - Page Not Found</h1><p>The requested URL was not found on the server.</p>", 404
    
    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        return f"<h1>500 - Internal Server Error</h1><p>An internal server error occurred.</p>", 500

    # Add cache-busting headers to force fresh content
    @app.after_request
    def add_cache_busting_headers(response):
        """Add headers to prevent caching of dynamic content"""
        if response.mimetype in ['text/html', 'text/css', 'application/javascript', 'application/json']:
            response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
            response.headers['Pragma'] = 'no-cache'
            response.headers['Expires'] = '0'
            # Add a timestamp to force refresh
            import time
            response.headers['X-Timestamp'] = str(int(time.time()))
        return response

    return app


if __name__ == '__main__':
    print("Starting SalesBreachPro (modular version)...")
    app = create_app()
    if app:
        print("Application ready! Visit: http://localhost:5001")
        app.run(debug=True, host='0.0.0.0', port=5001)
    else:
        print("Failed to create application!")