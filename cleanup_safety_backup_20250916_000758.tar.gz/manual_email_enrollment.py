#!/usr/bin/env python3
"""
Manual email enrollment and sequence triggering
This will manually create the email sequences for testing
"""

import os
import sys
from datetime import datetime, timedelta

# Add the app directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from models.database import db, Contact, Campaign, Email, EmailTemplate, FollowUpSequence

def create_email_sequence_manually():
    """Manually create email sequence for the breached contact"""
    print("=" * 60)
    print("MANUAL EMAIL SEQUENCE CREATION")
    print("=" * 60)

    app = create_app()
    with app.app_context():
        # Get the contact
        contact = Contact.query.filter_by(email="info@moaz.ca").first()
        if not contact:
            print("❌ Contact info@moaz.ca not found!")
            return

        print(f"✅ Found contact: {contact.email} (Status: {contact.breach_status})")

        # Get the appropriate campaign based on breach status
        if contact.breach_status == "breached":
            campaign = Campaign.query.filter_by(name="Test Breached Campaign").first()
            template = EmailTemplate.query.filter_by(name="Test Breached Template").first()
            sequence = FollowUpSequence.query.filter_by(name="Breached Email Sequence").first()
        else:
            campaign = Campaign.query.filter_by(name="Test Non-Breached Campaign").first()
            template = EmailTemplate.query.filter_by(name="Test Non-Breached Template").first()
            sequence = FollowUpSequence.query.filter_by(name="Non-Breached Email Sequence").first()

        if not campaign or not template or not sequence:
            print(f"❌ Missing components - Campaign: {campaign is not None}, Template: {template is not None}, Sequence: {sequence is not None}")
            return

        print(f"✅ Found campaign: {campaign.name}")
        print(f"✅ Found template: {template.name}")
        print(f"✅ Found sequence: {sequence.name} with {len(sequence.steps)} steps")

        # Create emails based on the sequence steps
        base_time = datetime.utcnow()
        created_emails = []

        for step_data in sequence.steps:
            step_num = step_data.get('step', 1)
            delay_minutes = step_data.get('delay_minutes', 0)

            # Calculate when this email should be sent
            scheduled_time = base_time + timedelta(minutes=delay_minutes)

            # Create the email record
            email = Email(
                contact_id=contact.id,
                campaign_id=campaign.id,
                template_id=template.id,
                subject=step_data.get('subject', template.subject_line),
                body=template.email_body.format(
                    current_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    contact_email=contact.email
                ),
                status='scheduled',
                scheduled_for=scheduled_time,
                created_at=datetime.utcnow(),
                sequence_step=step_num,
                sender_email=campaign.sender_email or "noreply@savety.online",
                sender_name=campaign.sender_name or "Security System"
            )

            db.session.add(email)
            created_emails.append(email)

            print(f"📧 Created email {step_num}: scheduled for {scheduled_time} ({delay_minutes} min delay)")

        # Commit all emails
        db.session.commit()

        print(f"\n✅ Successfully created {len(created_emails)} emails!")

        # Show the schedule
        print("\n📅 EMAIL SCHEDULE:")
        for email in created_emails:
            status_icon = "⏰" if email.status == "scheduled" else "✅"
            print(f"  {status_icon} Step {email.sequence_step}: {email.scheduled_for} - {email.subject}")

        # Mark contact as enrolled in campaign
        # Note: You might want to create an enrollment table for this
        print(f"\n🎯 Contact {contact.email} enrolled in {campaign.name}")

        return True

if __name__ == "__main__":
    create_email_sequence_manually()