#!/usr/bin/python3

import sys
import os
import cgitb
from wsgiref.handlers import CGIHandler

# Enable CGI error reporting
cgitb.enable()

# Get current directory and add to path
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

os.chdir(current_dir)

# Set required environment variables
os.environ.setdefault('REQUEST_METHOD', 'GET')
os.environ.setdefault('SERVER_NAME', 'marketing.savety.online')
os.environ.setdefault('SERVER_PORT', '443')
os.environ.setdefault('SCRIPT_NAME', '/index.py')
os.environ.setdefault('PATH_INFO', '/')
os.environ.setdefault('QUERY_STRING', '')
os.environ.setdefault('CONTENT_TYPE', '')
os.environ.setdefault('CONTENT_LENGTH', '0')
os.environ.setdefault('HTTP_HOST', 'marketing.savety.online')
os.environ.setdefault('HTTPS', 'on')

# Import and create Flask app
try:
    from app import create_app
    application = create_app()
    application.config['ENV'] = 'production'
    application.config['DEBUG'] = False

    # Use the standard CGI handler
    CGIHandler().run(application)

except Exception as e:
    print("Content-Type: text/html")
    print("Status: 500 Internal Server Error")
    print()
    print(f"""
    <!DOCTYPE html>
    <html>
    <head><title>Error</title></head>
    <body>
        <h1>Application Error</h1>
        <p>Error: {str(e)}</p>
    </body>
    </html>
    """)