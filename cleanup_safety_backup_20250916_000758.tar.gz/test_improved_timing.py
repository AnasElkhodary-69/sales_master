#!/usr/bin/env python3
"""
Test improved email timing with better precision
"""
import time
from datetime import datetime, timedelta
from app import create_app
from models.database import db, Contact, Campaign, EmailSequence, ContactCampaignStatus, Email
from services.email_sequence_service import EmailSequenceService
from services.email_processor import EmailProcessor

def test_improved_timing():
    """Test the improved email timing system"""
    print("=== IMPROVED EMAIL TIMING TEST ===")
    
    app = create_app()
    with app.app_context():
        # Clean up test data
        test_email = "timing_improved@moaz.ca"
        contact = Contact.query.filter_by(email=test_email).first()
        
        if contact:
            # Clean up existing sequences and emails
            EmailSequence.query.filter_by(contact_id=contact.id).delete()
            ContactCampaignStatus.query.filter_by(contact_id=contact.id).delete() 
            Email.query.filter_by(contact_id=contact.id).delete()
            db.session.commit()
            print(f"Cleaned up existing test data for {test_email}")
        else:
            # Create test contact
            contact = Contact(
                email=test_email,
                domain="moaz.ca", 
                breach_status="not_breached"
            )
            db.session.add(contact)
            db.session.flush()
            print(f"Created test contact: {test_email}")
        
        # Get campaign
        campaign = Campaign.query.filter_by(template_type="not_breached").first()
        print(f"Using campaign: {campaign.name} (ID: {campaign.id})")
        
        # Test 1: Enrollment and scheduling
        print("\n--- TEST 1: EMAIL SCHEDULING ---")
        sequence_service = EmailSequenceService()
        enrollment_time = datetime.utcnow()
        
        result = sequence_service.enroll_contact_in_campaign(
            contact_id=contact.id,
            campaign_id=campaign.id,
            force_breach_check=False
        )
        
        if result['success']:
            print(f"[OK] Enrollment successful! {result['emails_scheduled']} emails scheduled")
            
            # Check scheduled times
            sequences = EmailSequence.query.filter_by(
                contact_id=contact.id,
                campaign_id=campaign.id
            ).order_by(EmailSequence.sequence_step).all()
            
            print("Scheduled times:")
            for seq in sequences:
                delay_from_enrollment = seq.scheduled_datetime - enrollment_time
                print(f"  Step {seq.sequence_step}: {seq.scheduled_datetime} (+{delay_from_enrollment})")
                
                # Verify step 0 is immediate
                if seq.sequence_step == 0:
                    if delay_from_enrollment.total_seconds() <= 5:
                        print(f"    [OK] Step 0 is immediate (<=5 seconds delay)")
                    else:
                        print(f"    [ERROR] Step 0 has unexpected delay: {delay_from_enrollment}")
        else:
            print(f"[ERROR] Enrollment failed: {result.get('error')}")
            return
        
        # Test 2: Email processing precision
        print("\n--- TEST 2: EMAIL PROCESSING PRECISION ---")
        email_processor = EmailProcessor()
        
        # Check what emails are ready now
        processing_time = datetime.utcnow()
        print(f"Processing time: {processing_time}")
        
        # Manually trigger processing to see timing behavior
        result = email_processor.process_scheduled_emails()
        print(f"Processing result: {result}")
        
        # Check if emails were actually sent
        sent_emails = Email.query.filter_by(contact_id=contact.id).all()
        print(f"Emails sent: {len(sent_emails)}")
        
        for email in sent_emails:
            send_time = email.sent_at or email.created_at
            delay_from_enrollment = send_time - enrollment_time
            print(f"  Email ID {email.id}: sent at {send_time} (+{delay_from_enrollment} from enrollment)")
        
        # Test 3: Wait and process again  
        print("\n--- TEST 3: DELAYED PROCESSING TEST ---")
        print("Waiting 2 minutes to test follow-up email timing...")
        
        # Fast simulation - just check what would be processed
        future_time = datetime.utcnow() + timedelta(minutes=6)  # 6 minutes in future
        print(f"Simulating time: {future_time}")
        
        # Check sequences that would be ready at future time
        future_ready = []
        for seq in sequences:
            if seq.scheduled_datetime <= future_time and seq.status == 'scheduled':
                time_until_ready = seq.scheduled_datetime - datetime.utcnow()
                future_ready.append((seq, time_until_ready))
        
        print("Sequences that would be ready in 6 minutes:")
        for seq, time_until in future_ready:
            print(f"  Step {seq.sequence_step}: ready in {time_until}")
        
        print("\n=== TIMING TEST COMPLETE ===")

if __name__ == "__main__":
    test_improved_timing()