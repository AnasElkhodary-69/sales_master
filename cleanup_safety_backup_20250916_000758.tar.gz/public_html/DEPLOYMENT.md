# SalesBreachPro Deployment Guide

## 🚀 GitHub Deployment Instructions

### 1. Create GitHub Repository

1. Go to [GitHub](https://github.com) and sign in
2. Click the "+" icon in the top right corner
3. Select "New repository"
4. Name it `salesbreachpro` (or your preferred name)
5. Add description: "Flask-based email automation platform with breach data integration"
6. Choose visibility (Public or Private)
7. **Do NOT** initialize with README, .gitignore, or license (we already have these)
8. Click "Create repository"

### 2. Connect Local Repository to GitHub

```bash
# Navigate to your project directory
cd "C:\Users\M\Desktop\Automated Email"

# Add GitHub remote
git remote add origin https://github.com/YOUR_USERNAME/salesbreachpro.git

# Verify the remote was added
git remote -v

# Push to GitHub
git branch -M main
git push -u origin main
```

### 3. Environment Setup for Collaborators

After cloning the repository, team members should:

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/salesbreachpro.git
cd salesbreachpro

# Create virtual environment
python -m venv venv

# Activate virtual environment
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Create environment file
cp .env.example .env
# Edit .env with your actual credentials

# Initialize database
python -c "from run import create_simple_app; app = create_simple_app(); app.app_context().push(); from models.database import db; db.create_all(); print('Database initialized!')"

# Run the application
python run.py
```

## 🌐 Production Deployment Options

### Option 1: Heroku Deployment

1. **Install Heroku CLI**
   ```bash
   # Download from https://devcenter.heroku.com/articles/heroku-cli
   ```

2. **Create Heroku App**
   ```bash
   heroku login
   heroku create salesbreachpro-app
   ```

3. **Add Environment Variables**
   ```bash
   heroku config:set FLASK_ENV=production
   heroku config:set SECRET_KEY=your-production-secret-key
   heroku config:set FLAWTRACK_API_TOKEN=your-token
   heroku config:set AWS_ACCESS_KEY_ID=your-aws-key
   heroku config:set AWS_SECRET_ACCESS_KEY=your-aws-secret
   ```

4. **Create Procfile**
   ```
   web: gunicorn run:app
   release: python -c "from run import create_simple_app; app = create_simple_app(); app.app_context().push(); from models.database import db; db.create_all()"
   ```

5. **Deploy**
   ```bash
   git add .
   git commit -m "Add Heroku configuration"
   git push heroku main
   ```

### Option 2: AWS EC2 Deployment

1. **Launch EC2 Instance**
   - Choose Ubuntu 20.04 LTS
   - t2.medium or larger for production
   - Configure security groups (HTTP/HTTPS)

2. **Server Setup**
   ```bash
   # Update system
   sudo apt update && sudo apt upgrade -y
   
   # Install Python and dependencies
   sudo apt install python3 python3-pip python3-venv nginx supervisor -y
   
   # Clone repository
   git clone https://github.com/YOUR_USERNAME/salesbreachpro.git
   cd salesbreachpro
   
   # Setup virtual environment
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   pip install gunicorn
   ```

3. **Configure Nginx**
   ```nginx
   # /etc/nginx/sites-available/salesbreachpro
   server {
       listen 80;
       server_name your-domain.com;
       
       location / {
           proxy_pass http://127.0.0.1:5000;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       }
   }
   ```

4. **Configure Supervisor**
   ```ini
   # /etc/supervisor/conf.d/salesbreachpro.conf
   [program:salesbreachpro]
   command=/home/ubuntu/salesbreachpro/venv/bin/gunicorn -w 3 -b 127.0.0.1:5000 run:app
   directory=/home/ubuntu/salesbreachpro
   user=ubuntu
   autostart=true
   autorestart=true
   redirect_stderr=true
   stdout_logfile=/var/log/salesbreachpro.log
   ```

### Option 3: Docker Deployment

1. **Create Dockerfile**
   ```dockerfile
   FROM python:3.9-slim
   
   WORKDIR /app
   
   COPY requirements.txt .
   RUN pip install --no-cache-dir -r requirements.txt
   
   COPY . .
   
   RUN python -c "from run import create_simple_app; app = create_simple_app(); app.app_context().push(); from models.database import db; db.create_all()"
   
   EXPOSE 5000
   
   CMD ["gunicorn", "--bind", "0.0.0.0:5000", "run:app"]
   ```

2. **Create docker-compose.yml**
   ```yaml
   version: '3.8'
   services:
     web:
       build: .
       ports:
         - "5000:5000"
       environment:
         - FLASK_ENV=production
         - SECRET_KEY=your-secret-key
       volumes:
         - ./data:/app/data
   ```

3. **Deploy**
   ```bash
   docker-compose up -d
   ```

## 🔒 Security Checklist

### Pre-Production Security

- [ ] Change default SECRET_KEY
- [ ] Set up proper environment variables
- [ ] Configure HTTPS/SSL certificates
- [ ] Set up firewall rules
- [ ] Enable rate limiting
- [ ] Configure proper CORS settings
- [ ] Set up database backups
- [ ] Configure log rotation
- [ ] Set up monitoring and alerts

### AWS SES Configuration

1. **Verify Domain**
   - Add domain to AWS SES
   - Configure DKIM records
   - Set up SPF records

2. **Email Authentication**
   ```
   SPF Record: "v=spf1 include:amazonses.com ~all"
   DKIM: Configure via AWS SES console
   DMARC: "v=DMARC1; p=quarantine; rua=mailto:dmarc@yourdomain.com"
   ```

3. **Sending Limits**
   - Start with sandbox mode
   - Request production access
   - Monitor bounce/complaint rates

## 📊 Monitoring & Maintenance

### Application Monitoring

```python
# Add to your Flask app
import logging
from logging.handlers import RotatingFileHandler

if not app.debug:
    file_handler = RotatingFileHandler('logs/salesbreachpro.log', maxBytes=10240, backupCount=10)
    file_handler.setFormatter(logging.Formatter(
        '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
    ))
    file_handler.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)
```

### Database Backups

```bash
# SQLite backup script
#!/bin/bash
backup_dir="/path/to/backups"
timestamp=$(date +"%Y%m%d_%H%M%S")
cp data/app.db "$backup_dir/app_backup_$timestamp.db"

# Keep only last 30 days
find "$backup_dir" -name "app_backup_*.db" -mtime +30 -delete
```

### Health Check Endpoint

```python
@app.route('/health')
def health_check():
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'version': '1.0.0'
    })
```

## 🔄 CI/CD Pipeline

### GitHub Actions Example

```yaml
# .github/workflows/deploy.yml
name: Deploy to Production

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: 3.9
    
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
    
    - name: Run tests
      run: |
        python -m pytest tests/
    
    - name: Deploy to server
      run: |
        # Add your deployment script here
        echo "Deploying to production server..."
```

## 📞 Support & Troubleshooting

### Common Issues

1. **Database Connection Errors**
   - Check file permissions
   - Verify database path
   - Ensure data directory exists

2. **Email Delivery Issues**
   - Verify AWS SES configuration
   - Check domain verification
   - Monitor bounce rates

3. **FlawTrack API Errors**
   - Validate API token
   - Check rate limits
   - Verify endpoint URLs

### Getting Help

- Check application logs: `logs/salesbreachpro.log`
- Review database status: `/health` endpoint
- Monitor server resources: CPU, memory, disk space
- Check external service status: AWS SES, FlawTrack API

---

**Ready for Production!** 🚀

Your SalesBreachPro application is now ready for deployment. Choose the deployment option that best fits your infrastructure needs and follow the security checklist before going live.