#!/usr/bin/env python3
"""
Fix the sequence steps to start from 0 instead of 1
The email processor expects sequences to start from step 0
"""

import os
import sys

# Add the app directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from models.database import db, EmailSequence

def fix_sequence_steps():
    """Fix sequence steps to start from 0"""
    print("=" * 60)
    print("FIXING SEQUENCE STEPS TO START FROM 0")
    print("=" * 60)

    app = create_app()
    with app.app_context():
        # Get all sequences for our test contact
        sequences = EmailSequence.query.filter_by(
            contact_id=1,  # info@moaz.ca
            campaign_id=1  # Test Breached Campaign
        ).order_by(EmailSequence.sequence_step).all()

        print(f"Found {len(sequences)} sequences to fix:")

        for seq in sequences:
            old_step = seq.sequence_step
            new_step = old_step - 1  # Convert from 1-based to 0-based

            print(f"  Sequence {seq.id}: Step {old_step} -> Step {new_step}")
            print(f"    Scheduled: {seq.scheduled_datetime}")

            seq.sequence_step = new_step

        db.session.commit()
        print("\n✅ All sequence steps fixed!")

        # Show the corrected schedule
        print("\n📅 CORRECTED SEQUENCE SCHEDULE:")
        corrected_sequences = EmailSequence.query.filter_by(
            contact_id=1,
            campaign_id=1
        ).order_by(EmailSequence.sequence_step).all()

        for seq in corrected_sequences:
            status_icon = "⏰" if seq.status == "scheduled" else "✅" if seq.status == "sent" else "❌"
            print(f"  {status_icon} Step {seq.sequence_step}: {seq.scheduled_datetime} - Status: {seq.status}")

if __name__ == "__main__":
    fix_sequence_steps()