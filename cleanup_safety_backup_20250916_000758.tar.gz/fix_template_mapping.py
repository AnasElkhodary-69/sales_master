#!/usr/bin/env python3
"""
Fix template mapping issue
The EmailSequence uses 'proactive' but template has 'low' risk_level
"""

import os
import sys

# Add the app directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from models.database import db, EmailSequence

def fix_template_mapping():
    """Fix the template mapping for non-breached sequences"""
    print("=" * 60)
    print("FIXING TEMPLATE MAPPING")
    print("=" * 60)

    app = create_app()
    with app.app_context():
        # Find non-breached sequences with wrong template_type
        sequences = EmailSequence.query.filter_by(template_type='proactive').all()

        print(f"Found {len(sequences)} sequences with template_type='proactive'")

        for seq in sequences:
            contact = seq.contact
            print(f"Sequence {seq.id}: Contact {contact.email} (breach_status: {contact.breach_status})")

            # For non-breached contacts, change template_type to 'low' to match template risk_level
            if contact.breach_status == 'not_breached':
                old_type = seq.template_type
                seq.template_type = 'low'  # This should match the template risk_level
                print(f"  Changed template_type: '{old_type}' -> '{seq.template_type}'")

        db.session.commit()
        print("\n✅ Template mapping fixed!")

        # Also check breached sequences - they should use 'high' to match template risk_level
        breached_sequences = EmailSequence.query.filter_by(template_type='breached').all()
        print(f"\nFound {len(breached_sequences)} sequences with template_type='breached'")

        for seq in breached_sequences:
            contact = seq.contact
            if contact and contact.breach_status == 'breached':
                old_type = seq.template_type
                seq.template_type = 'high'  # This should match the template risk_level
                print(f"Sequence {seq.id}: Changed template_type: '{old_type}' -> '{seq.template_type}'")

        db.session.commit()
        print("✅ All template mappings fixed!")

        # Show current state
        print("\n📊 CURRENT EMAIL SEQUENCES:")
        all_sequences = EmailSequence.query.order_by(EmailSequence.contact_id, EmailSequence.sequence_step).all()

        for seq in all_sequences:
            contact = seq.contact
            if contact:
                status_icon = "⏰" if seq.status == "scheduled" else "✅" if seq.status == "sent" else "❌"
                print(f"  {status_icon} Contact: {contact.email} ({contact.breach_status}) - Step {seq.sequence_step} - Template: {seq.template_type}")

if __name__ == "__main__":
    fix_template_mapping()