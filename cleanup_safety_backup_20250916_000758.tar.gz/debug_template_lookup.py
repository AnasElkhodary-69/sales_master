#!/usr/bin/env python3
"""
Debug the template lookup issue
"""

import os
import sys

# Add the app directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from models.database import db, EmailSequence, EmailTemplate

def debug_template_lookup():
    """Debug the template lookup for failed sequence"""
    print("=" * 60)
    print("DEBUG TEMPLATE LOOKUP")
    print("=" * 60)

    app = create_app()
    with app.app_context():
        # Get the failed sequence
        failed_seq = EmailSequence.query.filter_by(status='failed').first()
        if not failed_seq:
            print("❌ No failed sequence found!")
            return

        contact = failed_seq.contact
        print(f"✅ Found failed sequence: Contact {contact.email}")
        print(f"   EmailSequence ID: {failed_seq.id}")
        print(f"   Sequence Step: {failed_seq.sequence_step}")
        print(f"   Template Type from DB: '{failed_seq.template_type}'")
        print(f"   Contact Breach Status: '{contact.breach_status}'")

        # Try to manually lookup the template
        print(f"\n🔍 Manual Template Lookup:")
        print(f"   Looking for: step={failed_seq.sequence_step}, risk_level='{failed_seq.template_type}'")

        template = EmailTemplate.query.filter_by(
            sequence_step=failed_seq.sequence_step,
            risk_level=failed_seq.template_type,
            active=True
        ).first()

        if template:
            print(f"✅ FOUND: Template '{template.name}' (ID: {template.id})")
            print(f"   Risk Level: '{template.risk_level}'")
            print(f"   Sequence Step: {template.sequence_step}")
        else:
            print(f"❌ NOT FOUND")

            # Show what templates exist with this risk level
            templates_with_risk = EmailTemplate.query.filter_by(
                risk_level=failed_seq.template_type,
                active=True
            ).all()

            print(f"\n   Templates with risk_level='{failed_seq.template_type}':")
            for t in templates_with_risk:
                print(f"     - {t.name} (Step: {t.sequence_step})")

            # Show what templates exist for this step
            templates_with_step = EmailTemplate.query.filter_by(
                sequence_step=failed_seq.sequence_step,
                active=True
            ).all()

            print(f"\n   Templates for step={failed_seq.sequence_step}:")
            for t in templates_with_step:
                print(f"     - {t.name} (Risk: '{t.risk_level}')")

if __name__ == "__main__":
    debug_template_lookup()