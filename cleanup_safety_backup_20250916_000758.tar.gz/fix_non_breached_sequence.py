#!/usr/bin/env python3
"""
Fix the non-breached contact sequence
Clean up incorrect sequences and create proper ones
"""

import os
import sys
from datetime import datetime, timedelta

# Add the app directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from models.database import db, Contact, Campaign, EmailSequence, FollowUpSequence

def fix_non_breached_sequence():
    """Fix the non-breached contact sequence"""
    print("=" * 60)
    print("FIXING NON-BREACHED CONTACT SEQUENCE")
    print("=" * 60)

    app = create_app()
    with app.app_context():
        # Get the non-breached contact
        contact = Contact.query.filter_by(breach_status="not_breached").first()
        if not contact:
            print("❌ No non-breached contact found!")
            return False

        print(f"✅ Found non-breached contact: {contact.email} (ID: {contact.id})")

        # Delete all existing sequences for this contact
        existing_sequences = EmailSequence.query.filter_by(contact_id=contact.id).all()
        print(f"🗑️  Deleting {len(existing_sequences)} existing sequences")

        for seq in existing_sequences:
            db.session.delete(seq)

        db.session.commit()

        # Get the non-breached campaign
        campaign = Campaign.query.filter_by(template_type="low_risk").first()
        if not campaign:
            print("❌ No low_risk campaign found!")
            return False

        print(f"✅ Found campaign: {campaign.name} (ID: {campaign.id})")

        # Get the non-breached sequence definition
        sequence = FollowUpSequence.query.filter_by(risk_level="low").first()
        if not sequence:
            print("❌ No low risk sequence found!")
            return False

        print(f"✅ Found sequence definition: {sequence.name}")
        print(f"   Steps: {len(sequence.steps)}")

        # Create correct EmailSequence records (0-based indexing)
        base_time = datetime.utcnow()
        created_sequences = []

        for i, step_data in enumerate(sequence.steps):
            step_num = i  # 0-based: 0, 1
            delay_minutes = step_data.get('delay_minutes', 0)

            # Calculate when this email should be sent
            scheduled_datetime = base_time + timedelta(minutes=delay_minutes)

            # Create the EmailSequence record
            email_sequence = EmailSequence(
                contact_id=contact.id,
                campaign_id=campaign.id,
                sequence_step=step_num,
                template_type="proactive",  # Non-breached = proactive
                scheduled_date=scheduled_datetime.date(),
                scheduled_datetime=scheduled_datetime,
                status='scheduled',
                created_at=datetime.utcnow()
            )

            db.session.add(email_sequence)
            created_sequences.append(email_sequence)

            print(f"📧 Created sequence step {step_num}: scheduled for {scheduled_datetime} ({delay_minutes} min delay)")

        # Commit all sequences
        db.session.commit()

        print(f"\n✅ Successfully created {len(created_sequences)} email sequence steps!")

        # Show the complete schedule
        print("\n📅 CORRECTED NON-BREACHED EMAIL SEQUENCE:")
        all_sequences = EmailSequence.query.filter_by(
            contact_id=contact.id,
            campaign_id=campaign.id
        ).order_by(EmailSequence.sequence_step).all()

        for seq in all_sequences:
            status_icon = "⏰" if seq.status == "scheduled" else "✅" if seq.status == "sent" else "❌"
            print(f"  {status_icon} Step {seq.sequence_step}: {seq.scheduled_datetime} - Status: {seq.status}")

        print(f"\n🎯 Contact {contact.email} properly enrolled in {campaign.name}")

        return True

if __name__ == "__main__":
    fix_non_breached_sequence()