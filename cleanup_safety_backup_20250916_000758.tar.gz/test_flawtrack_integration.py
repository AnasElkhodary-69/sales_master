#!/usr/bin/env python3
"""
Comprehensive FlawTrack API Integration Test Suite
Tests the new FlawTrack API implementation with both legacy and new API endpoints
"""
import os
import sys
import time
import requests
from datetime import datetime

# Add project root to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils.flawtrack_config import get_flawtrack_api, get_api_config, validate_configuration
from services.flawtrack_api import FlawTrackAPI
from services.flawtrack_monitor import perform_health_check, get_monitor

def print_header(title):
    """Print a formatted test section header"""
    print("\n" + "="*60)
    print(f"  {title}")
    print("="*60)

def print_test(test_name, status="RUNNING"):
    """Print test status"""
    if status == "RUNNING":
        print(f"🔄 {test_name}...")
    elif status == "PASS":
        print(f"✅ {test_name} - PASSED")
    elif status == "FAIL":
        print(f"❌ {test_name} - FAILED")
    elif status == "SKIP":
        print(f"⏭️  {test_name} - SKIPPED")

def test_configuration():
    """Test FlawTrack configuration validation"""
    print_header("CONFIGURATION TESTS")

    try:
        print_test("Configuration Loading", "RUNNING")
        config = get_api_config()
        print(f"   API Version: {config['version']}")
        print(f"   Endpoint: {config['endpoint']}")
        print(f"   Scanning Enabled: {config['scanning_enabled']}")
        print_test("Configuration Loading", "PASS")

        print_test("Configuration Validation", "RUNNING")
        validation = validate_configuration()
        if validation['valid']:
            print("   ✓ Configuration is valid")
            print_test("Configuration Validation", "PASS")
        else:
            print("   ✗ Configuration has errors:")
            for error in validation['errors']:
                print(f"     - {error}")
            print_test("Configuration Validation", "FAIL")
            return False

        if validation['warnings']:
            print("   ⚠️  Configuration warnings:")
            for warning in validation['warnings']:
                print(f"     - {warning}")

        return True

    except Exception as e:
        print(f"   Error: {str(e)}")
        print_test("Configuration Tests", "FAIL")
        return False

def test_api_initialization():
    """Test FlawTrack API initialization"""
    print_header("API INITIALIZATION TESTS")

    try:
        print_test("API Instance Creation", "RUNNING")
        api = get_flawtrack_api()

        if api is None:
            print("   ✗ Failed to create API instance")
            print_test("API Instance Creation", "FAIL")
            return None

        print("   ✓ API instance created successfully")

        # Get API info
        api_info = api.get_api_info()
        print(f"   API Version: {api_info['api_version']}")
        print(f"   Endpoint: {api_info['endpoint']}")
        print(f"   Health Check: {'Available' if api_info['has_health_check'] else 'Not Available'}")
        print(f"   Service Search: {'Supported' if api_info['supports_service_search'] else 'Not Supported'}")
        print(f"   Source Separation: {'Supported' if api_info['supports_source_separation'] else 'Not Supported'}")
        print(f"   Deduplication: {'Supported' if api_info['supports_deduplication'] else 'Not Supported'}")

        print_test("API Instance Creation", "PASS")
        return api

    except Exception as e:
        print(f"   Error: {str(e)}")
        print_test("API Instance Creation", "FAIL")
        return None

def test_health_check(api):
    """Test API health check functionality"""
    print_header("HEALTH CHECK TESTS")

    try:
        print_test("Health Check", "RUNNING")
        start_time = time.time()
        health_result = api.health_check()
        end_time = time.time()

        print(f"   Status: {health_result['status']}")
        print(f"   Healthy: {health_result['healthy']}")
        print(f"   Message: {health_result['message']}")
        print(f"   Response Time: {health_result['response_time_ms']}ms")
        print(f"   API Version: {health_result['api_version']}")
        print(f"   Test Duration: {int((end_time - start_time) * 1000)}ms")

        if health_result['service_info']:
            print("   Service Info:")
            for key, value in health_result['service_info'].items():
                print(f"     {key}: {value}")

        if health_result['healthy']:
            print_test("Health Check", "PASS")
            return True
        else:
            print_test("Health Check", "FAIL")
            return False

    except Exception as e:
        print(f"   Error: {str(e)}")
        print_test("Health Check", "FAIL")
        return False

def test_domain_search(api):
    """Test domain search functionality"""
    print_header("DOMAIN SEARCH TESTS")

    test_domains = ['example.com', 'test.org', 'google.com']

    for domain in test_domains:
        try:
            print_test(f"Domain Search: {domain}", "RUNNING")
            start_time = time.time()
            result = api.get_breach_data(domain)
            end_time = time.time()

            print(f"   Query Time: {int((end_time - start_time) * 1000)}ms")

            if result is not None:
                if isinstance(result, list):
                    print(f"   ✓ Found {len(result)} credential records")
                    if len(result) > 0:
                        print("   Sample record fields:")
                        first_record = result[0]
                        for key in list(first_record.keys())[:5]:  # Show first 5 fields
                            print(f"     {key}: {first_record[key]}")
                else:
                    print(f"   ✓ Received data: {type(result)}")
                print_test(f"Domain Search: {domain}", "PASS")
            else:
                print("   ⚠️  No data returned (API may be unavailable)")
                print_test(f"Domain Search: {domain}", "SKIP")

        except Exception as e:
            print(f"   Error: {str(e)}")
            print_test(f"Domain Search: {domain}", "FAIL")

def test_service_search(api):
    """Test service search functionality (new API only)"""
    print_header("SERVICE SEARCH TESTS")

    api_info = api.get_api_info()
    if not api_info['supports_service_search']:
        print_test("Service Search", "SKIP")
        print("   Service search not supported in current API version")
        return

    test_services = ['gmail.com', 'github.com', 'facebook.com']

    for service in test_services:
        try:
            print_test(f"Service Search: {service}", "RUNNING")
            start_time = time.time()
            result = api.search_by_service(service)
            end_time = time.time()

            print(f"   Query Time: {int((end_time - start_time) * 1000)}ms")

            if result is not None:
                print(f"   ✓ Found {len(result)} credential records for service")
                print_test(f"Service Search: {service}", "PASS")
            else:
                print("   ⚠️  No data returned")
                print_test(f"Service Search: {service}", "SKIP")

        except Exception as e:
            print(f"   Error: {str(e)}")
            print_test(f"Service Search: {service}", "FAIL")

def test_source_separation(api):
    """Test BigQuery/Database source separation (new API only)"""
    print_header("SOURCE SEPARATION TESTS")

    api_info = api.get_api_info()
    if not api_info['supports_source_separation']:
        print_test("Source Separation", "SKIP")
        print("   Source separation not supported in current API version")
        return

    test_domain = 'example.com'

    try:
        print_test("BigQuery Search", "RUNNING")
        bigquery_result = api.get_bigquery_only_results(test_domain)
        if bigquery_result is not None:
            print(f"   ✓ BigQuery returned {len(bigquery_result)} records")
            print_test("BigQuery Search", "PASS")
        else:
            print("   ⚠️  BigQuery returned no data")
            print_test("BigQuery Search", "SKIP")

        print_test("Database Search", "RUNNING")
        database_result = api.get_database_only_results(test_domain)
        if database_result is not None:
            print(f"   ✓ Database returned {len(database_result)} records")
            print_test("Database Search", "PASS")
        else:
            print("   ⚠️  Database returned no data")
            print_test("Database Search", "SKIP")

    except Exception as e:
        print(f"   Error: {str(e)}")
        print_test("Source Separation", "FAIL")

def test_batch_processing(api):
    """Test batch domain lookup functionality"""
    print_header("BATCH PROCESSING TESTS")

    test_domains = ['example.com', 'test.org', 'sample.net']

    try:
        print_test("Batch Domain Lookup", "RUNNING")
        start_time = time.time()

        results = api.batch_domain_lookup(test_domains, delay=0.5)  # Shorter delay for testing

        end_time = time.time()
        total_time = end_time - start_time

        print(f"   Total Processing Time: {total_time:.2f}s")
        print(f"   Domains Processed: {len(results)}")
        print(f"   Average Time per Domain: {(total_time/len(results)):.2f}s")

        for domain, result in results.items():
            status = result.get('breach_status', 'unknown')
            records = result.get('records_affected', 0)
            print(f"   {domain}: {status} ({records} records)")

        print_test("Batch Domain Lookup", "PASS")

    except Exception as e:
        print(f"   Error: {str(e)}")
        print_test("Batch Domain Lookup", "FAIL")

def test_monitoring_service():
    """Test FlawTrack monitoring service"""
    print_header("MONITORING SERVICE TESTS")

    try:
        print_test("Monitor Initialization", "RUNNING")
        monitor = get_monitor()
        print("   ✓ Monitor instance created")

        # Get monitor info
        monitor_info = monitor.get_monitoring_info()
        print(f"   Monitoring Enabled: {monitor_info['monitoring_enabled']}")
        print(f"   Check Interval: {monitor_info['check_interval_seconds']}s")
        print(f"   History Size: {monitor_info['history_size']}")

        print_test("Monitor Initialization", "PASS")

        print_test("Health Check via Monitor", "RUNNING")
        status = perform_health_check()

        print(f"   Status: {status.status}")
        print(f"   Healthy: {status.healthy}")
        print(f"   Message: {status.message}")
        print(f"   Timestamp: {status.timestamp}")

        print_test("Health Check via Monitor", "PASS" if status.healthy else "FAIL")

        # Get availability stats
        print_test("Availability Statistics", "RUNNING")
        stats = monitor.get_availability_stats(1)  # Last 1 hour

        print(f"   Availability: {stats['availability_percentage']}%")
        print(f"   Total Checks: {stats['total_checks']}")
        print(f"   Healthy Checks: {stats['healthy_checks']}")
        print(f"   Average Response Time: {stats['average_response_time_ms']}ms")

        print_test("Availability Statistics", "PASS")

    except Exception as e:
        print(f"   Error: {str(e)}")
        print_test("Monitoring Service", "FAIL")

def test_error_handling(api):
    """Test error handling and edge cases"""
    print_header("ERROR HANDLING TESTS")

    try:
        print_test("Invalid Domain Handling", "RUNNING")
        result = api.get_breach_data("invalid.domain.that.does.not.exist.anywhere")
        if result is not None and isinstance(result, list):
            print(f"   ✓ Handled invalid domain gracefully (returned {len(result)} results)")
        else:
            print("   ✓ Handled invalid domain gracefully (returned None)")
        print_test("Invalid Domain Handling", "PASS")

        print_test("Empty Domain Handling", "RUNNING")
        result = api.get_breach_data("")
        print("   ✓ Handled empty domain without crashing")
        print_test("Empty Domain Handling", "PASS")

        print_test("Special Character Handling", "RUNNING")
        result = api.get_breach_data("test@domain.com")
        print("   ✓ Handled domain with special characters")
        print_test("Special Character Handling", "PASS")

    except Exception as e:
        print(f"   Error: {str(e)}")
        print_test("Error Handling", "FAIL")

def main():
    """Run comprehensive FlawTrack integration tests"""
    print_header("FLAWTRACK API INTEGRATION TEST SUITE")
    print(f"Test Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    # Test configuration
    if not test_configuration():
        print("\n❌ Configuration tests failed. Cannot continue.")
        return False

    # Initialize API
    api = test_api_initialization()
    if api is None:
        print("\n❌ API initialization failed. Cannot continue.")
        return False

    # Run all tests
    test_results = []

    # Core functionality tests
    test_results.append(test_health_check(api))
    test_domain_search(api)
    test_service_search(api)
    test_source_separation(api)
    test_batch_processing(api)

    # System tests
    test_monitoring_service()
    test_error_handling(api)

    # Summary
    print_header("TEST SUMMARY")
    print(f"Test Completed: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    api_info = api.get_api_info()
    print(f"Tested API: {api_info['api_version']}")
    print(f"Endpoint: {api_info['endpoint']}")

    passed_tests = sum(1 for result in test_results if result)
    total_tests = len(test_results)

    if passed_tests == total_tests:
        print(f"\n🎉 ALL CRITICAL TESTS PASSED ({passed_tests}/{total_tests})")
        print("✅ FlawTrack API integration is working correctly!")
        return True
    else:
        print(f"\n⚠️  SOME TESTS FAILED ({passed_tests}/{total_tests} passed)")
        print("❌ FlawTrack API integration may have issues.")
        return False

if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n\n⏹️  Tests interrupted by user")
        sys.exit(130)
    except Exception as e:
        print(f"\n\n💥 Unexpected error: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)