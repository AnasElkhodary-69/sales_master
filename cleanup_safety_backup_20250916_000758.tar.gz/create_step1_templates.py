#!/usr/bin/env python3
"""
Create missing step 1 templates for the email sequence
"""

import os
import sys

# Add the app directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from models.database import db, EmailTemplate

def create_step1_templates():
    """Create the missing step 1 templates"""
    print("=" * 60)
    print("CREATING STEP 1 EMAIL TEMPLATES")
    print("=" * 60)

    app = create_app()
    with app.app_context():
        # Create step 1 template for non-breached (low risk)
        low_template = EmailTemplate(
            name="Non-Breached Follow-up",
            template_type="follow_up",
            risk_level="low",
            sequence_step=1,
            subject_line="Follow-up: Security Assessment for {company}",
            email_body="""Hello {first_name},

I wanted to follow up on my previous email regarding a security assessment for {company}.

As cyber threats continue to evolve, it's important to stay proactive about your organization's security posture. We specialize in helping companies identify and address potential vulnerabilities before they become issues.

Would you be available for a brief 15-minute call this week to discuss how we can help strengthen {company}'s security?

Best regards,
{sender_name}""",
            active=True,
            delay_amount=5,
            delay_unit="minutes"
        )

        # Create step 1 template for breached (high risk)
        high_template = EmailTemplate(
            name="Breached Follow-up",
            template_type="follow_up",
            risk_level="high",
            sequence_step=1,
            subject_line="URGENT Follow-up: {company} Security Breach Alert",
            email_body="""Hello {first_name},

This is a critical follow-up to my previous email regarding the security breach affecting {company}.

{breach_sample}

Time is of the essence when dealing with data breaches. Every day that passes increases the risk of:
- Identity theft affecting your customers/employees
- Regulatory fines and compliance issues
- Reputation damage

We can help you immediately assess the full scope of this breach and implement protective measures.

Can we schedule an emergency security consultation within the next 24 hours?

Urgently,
{sender_name}""",
            active=True,
            delay_amount=5,
            delay_unit="minutes"
        )

        db.session.add(low_template)
        db.session.add(high_template)
        db.session.commit()

        print("✅ Created step 1 templates:")
        print(f"   - Low Risk (Step 1): '{low_template.name}' (ID: {low_template.id})")
        print(f"   - High Risk (Step 1): '{high_template.name}' (ID: {high_template.id})")

        # Verify all templates now
        print("\n📋 ALL ACTIVE TEMPLATES:")
        all_templates = EmailTemplate.query.filter_by(active=True).order_by(
            EmailTemplate.risk_level, EmailTemplate.sequence_step
        ).all()

        for template in all_templates:
            print(f"   {template.risk_level.upper()} Step {template.sequence_step}: {template.name}")

if __name__ == "__main__":
    create_step1_templates()