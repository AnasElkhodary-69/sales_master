#!/usr/bin/python3

import sys
import os

print("Content-Type: text/html\n")
print("<html><head><title>Python Test</title></head><body>")
print("<h1>Python CGI Test</h1>")
print(f"<p>Python Version: {sys.version}</p>")
print(f"<p>Current Directory: {os.getcwd()}</p>")
print(f"<p>Script Path: {os.path.abspath(__file__)}</p>")
print(f"<p>User: {os.getenv('USER', 'unknown')}</p>")

# Test Flask import
try:
    from app import create_app
    print("<p>✅ Flask app import: SUCCESS</p>")

    flask_app = create_app()
    print("<p>✅ Flask app creation: SUCCESS</p>")

    with flask_app.app_context():
        routes = list(flask_app.url_map.iter_rules())
        print(f"<p>✅ Routes registered: {len(routes)}</p>")

except Exception as e:
    print(f"<p>❌ Flask test failed: {str(e)}</p>")

print("</body></html>")