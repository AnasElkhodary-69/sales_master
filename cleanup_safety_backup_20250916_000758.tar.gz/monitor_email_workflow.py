#!/usr/bin/env python3
"""
Monitor the email workflow in real-time
Watch the EmailSequence records and Email records get processed
"""

import os
import sys
import time
from datetime import datetime

# Add the app directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from models.database import db, Contact, Campaign, Email, EmailTemplate, EmailSequence
from services.email_processor import EmailProcessor

def monitor_email_workflow(duration_minutes=15):
    """Monitor the email workflow for the specified duration"""
    print("=" * 60)
    print(f"MONITORING EMAIL WORKFLOW - {duration_minutes} MINUTES")
    print("=" * 60)

    app = create_app()
    start_time = datetime.now()
    last_check = start_time
    check_interval = 30  # seconds

    with app.app_context():
        # Get initial counts
        initial_sequences = EmailSequence.query.count()
        initial_emails = Email.query.count()

        print(f"🔍 Initial state:")
        print(f"   📧 EmailSequence records: {initial_sequences}")
        print(f"   📬 Email records: {initial_emails}")
        print(f"⏰ Starting monitoring at {start_time.strftime('%H:%M:%S')}")
        print()

        # Initialize email processor
        email_processor = EmailProcessor()

        while (datetime.now() - start_time).total_seconds() < duration_minutes * 60:
            current_time = datetime.now()
            elapsed = (current_time - start_time).total_seconds() / 60

            # Check every 30 seconds
            if (current_time - last_check).total_seconds() >= check_interval:
                print(f"⏱️  [{current_time.strftime('%H:%M:%S')}] Elapsed: {elapsed:.1f} min")

                # Check scheduled sequences
                scheduled_sequences = EmailSequence.query.filter_by(status='scheduled').all()
                sent_sequences = EmailSequence.query.filter_by(status='sent').all()

                print(f"   📊 Sequences - Scheduled: {len(scheduled_sequences)}, Sent: {len(sent_sequences)}")

                # Show upcoming sequences
                upcoming = [seq for seq in scheduled_sequences if seq.scheduled_datetime <= current_time]
                if upcoming:
                    print(f"   🚨 {len(upcoming)} sequences ready to process!")
                    for seq in upcoming:
                        print(f"      Step {seq.sequence_step}: Due at {seq.scheduled_datetime.strftime('%H:%M:%S')}")

                # Try to process emails
                try:
                    results = email_processor.process_scheduled_emails()
                    if results.get('emails_sent', 0) > 0 or results.get('sequences_processed', 0) > 0:
                        print(f"   ✅ Email processor results: {results}")
                except Exception as e:
                    print(f"   ❌ Email processing error: {e}")

                # Check actual emails created
                current_emails = Email.query.count()
                new_emails = current_emails - initial_emails
                if new_emails > 0:
                    print(f"   📬 Total emails created: {new_emails}")

                    # Show recent emails
                    recent_emails = Email.query.filter(
                        Email.id > initial_emails
                    ).order_by(Email.id.desc()).limit(3).all()

                    for email in recent_emails:
                        contact_email = email.contact.email if email.contact else "Unknown"
                        status_emoji = "✅" if email.status == "sent" else "⏰" if email.status == "pending" else "📧"
                        print(f"      {status_emoji} To: {contact_email} - Status: {email.status} - Subject: {email.subject[:50]}")

                print()
                last_check = current_time

            time.sleep(5)  # Check every 5 seconds for responsiveness

        # Final summary
        print("=" * 60)
        print("MONITORING COMPLETE - FINAL SUMMARY")
        print("=" * 60)

        final_sequences = EmailSequence.query.all()
        final_emails = Email.query.count()

        print(f"📊 EmailSequence Status Summary:")
        for status in ['scheduled', 'sent', 'failed', 'skipped_replied']:
            count = EmailSequence.query.filter_by(status=status).count()
            if count > 0:
                emoji = "⏰" if status == "scheduled" else "✅" if status == "sent" else "❌"
                print(f"   {emoji} {status.title()}: {count}")

        print(f"\n📬 Total emails created: {final_emails - initial_emails}")

        if final_emails > initial_emails:
            print(f"\n📧 Email Details:")
            all_emails = Email.query.filter(Email.id > initial_emails).all()
            for email in all_emails:
                contact_email = email.contact.email if email.contact else "Unknown"
                print(f"   To: {contact_email}")
                print(f"   Subject: {email.subject}")
                print(f"   Status: {email.status}")
                if email.sent_at:
                    print(f"   Sent: {email.sent_at}")
                print(f"   Created: {email.created_at}")
                print()

        print("✅ Workflow monitoring completed!")

if __name__ == "__main__":
    monitor_email_workflow(15)  # Monitor for 15 minutes