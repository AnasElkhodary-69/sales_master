#!/usr/bin/env python3
"""
Test Enhanced Analytics Dashboard with Complete Email Sequence Tracking
Creates test data and verifies the dashboard shows proper sequence analytics
"""

import os
import sys
from datetime import datetime, timedelta

# Add the app directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from models.database import (
    db, Contact, Campaign, Email, EmailSequence, EmailTemplate,
    ContactCampaignStatus
)


def create_test_data_for_analytics():
    """Create comprehensive test data for analytics dashboard"""
    print("=" * 70)
    print("CREATING TEST DATA FOR ENHANCED ANALYTICS DASHBOARD")
    print("=" * 70)

    app = create_app()
    with app.app_context():
        # Clean up any existing test data
        print("🧹 Cleaning up existing test data...")

        # Delete in correct order to respect foreign keys
        Email.query.filter(Email.subject.like('%Test Analytics%')).delete()
        EmailSequence.query.filter(EmailSequence.campaign_id.in_(
            db.session.query(Campaign.id).filter(Campaign.name.like('%Analytics Test%'))
        )).delete()
        ContactCampaignStatus.query.filter(ContactCampaignStatus.campaign_id.in_(
            db.session.query(Campaign.id).filter(Campaign.name.like('%Analytics Test%'))
        )).delete()
        Campaign.query.filter(Campaign.name.like('%Analytics Test%')).delete()
        Contact.query.filter(Contact.email.like('%analyticstest%')).delete()
        db.session.commit()

        # Create test campaigns
        print("\n📢 Creating test campaigns...")

        # Campaign 1: Breach Detection Campaign
        breach_campaign = Campaign(
            name="Analytics Test - Breach Detection",
            description="Test campaign for breached contacts",
            status="active",
            template_type="high",
            target_risk_levels=["high"],
            sender_email="emily.carter@savety.ai",
            sender_name="Security Team",
            auto_enroll=True,
            created_at=datetime.utcnow() - timedelta(days=7)
        )

        # Campaign 2: Proactive Security Campaign
        proactive_campaign = Campaign(
            name="Analytics Test - Proactive Security",
            description="Test campaign for non-breached contacts",
            status="active",
            template_type="low",
            target_risk_levels=["low"],
            sender_email="emily.carter@savety.ai",
            sender_name="Security Team",
            auto_enroll=True,
            created_at=datetime.utcnow() - timedelta(days=5)
        )

        db.session.add(breach_campaign)
        db.session.add(proactive_campaign)
        db.session.commit()

        print(f"✅ Created campaigns:")
        print(f"   - Breach Detection (ID: {breach_campaign.id})")
        print(f"   - Proactive Security (ID: {proactive_campaign.id})")

        # Create test contacts with varied scenarios
        print("\n👥 Creating test contacts...")

        test_contacts = [
            # Breached contacts
            {
                'email': 'john.doe.analyticstest@example.com',
                'first_name': 'John',
                'last_name': 'Doe',
                'company': 'TechCorp Inc',
                'breach_status': 'breached',
                'campaign': breach_campaign,
                'scenario': 'high_engagement'  # Opens and clicks everything
            },
            {
                'email': 'jane.smith.analyticstest@example.com',
                'first_name': 'Jane',
                'last_name': 'Smith',
                'company': 'SecureData Ltd',
                'breach_status': 'breached',
                'campaign': breach_campaign,
                'scenario': 'medium_engagement'  # Opens but doesn't click
            },
            {
                'email': 'bob.wilson.analyticstest@example.com',
                'first_name': 'Bob',
                'last_name': 'Wilson',
                'company': 'DataShield Corp',
                'breach_status': 'breached',
                'campaign': breach_campaign,
                'scenario': 'low_engagement'  # Only receives, doesn't engage
            },
            # Non-breached contacts
            {
                'email': 'alice.brown.analyticstest@example.com',
                'first_name': 'Alice',
                'last_name': 'Brown',
                'company': 'SafeTech Solutions',
                'breach_status': 'secure',
                'campaign': proactive_campaign,
                'scenario': 'replied'  # Opens and replies (stops sequence)
            },
            {
                'email': 'charlie.davis.analyticstest@example.com',
                'first_name': 'Charlie',
                'last_name': 'Davis',
                'company': 'CloudSecure Inc',
                'breach_status': 'secure',
                'campaign': proactive_campaign,
                'scenario': 'high_engagement'  # High engagement throughout
            }
        ]

        contacts = []
        for contact_data in test_contacts:
            contact = Contact(
                email=contact_data['email'],
                first_name=contact_data['first_name'],
                last_name=contact_data['last_name'],
                company=contact_data['company'],
                breach_status=contact_data['breach_status']
            )
            db.session.add(contact)
            contacts.append((contact, contact_data['campaign'], contact_data['scenario']))

        db.session.commit()
        print(f"✅ Created {len(contacts)} test contacts")

        # Create email sequences and emails for each contact
        print("\n📧 Creating email sequences and sent emails...")

        for contact, campaign, scenario in contacts:
            # Create ContactCampaignStatus
            status = ContactCampaignStatus(
                contact_id=contact.id,
                campaign_id=campaign.id,
                breach_status=contact.breach_status,
                current_sequence_step=3,  # Progressed through sequence
                sequence_completed_at=None if scenario != 'replied' else datetime.utcnow() - timedelta(days=1)
            )
            db.session.add(status)

            # Create email sequences and emails for multiple steps
            max_step = 2 if scenario == 'replied' else 3  # Replied contacts stop early

            for step in range(max_step):
                # Create EmailSequence
                sequence_time = datetime.utcnow() - timedelta(days=6-step, hours=step*2)

                email_seq = EmailSequence(
                    contact_id=contact.id,
                    campaign_id=campaign.id,
                    sequence_step=step,
                    template_type='high' if campaign.template_type == 'high' else 'low',
                    scheduled_date=sequence_time.date(),
                    scheduled_datetime=sequence_time,
                    status='sent'
                )
                db.session.add(email_seq)
                db.session.flush()  # Get ID

                # Create Email record
                email_type = 'initial' if step == 0 else f'follow_up_{step}'
                step_name = "Initial Email" if step == 0 else f"Follow-up {step}"

                email = Email(
                    contact_id=contact.id,
                    campaign_id=campaign.id,
                    email_type=email_type,
                    subject=f"Test Analytics - {step_name} for {contact.company}",
                    body=f"Test email content for {step_name}",
                    content=f"Test email content for {step_name}",
                    status='sent',
                    sent_at=sequence_time,
                    brevo_message_id=f"<test-{contact.id}-{step}-{int(sequence_time.timestamp())}@savety.ai>"
                )
                db.session.add(email)
                db.session.flush()  # Get ID

                # Link sequence to email
                email_seq.email_id = email.id

                # Add engagement based on scenario
                if scenario in ['high_engagement', 'medium_engagement', 'replied']:
                    # Add delivery
                    email.delivered_at = sequence_time + timedelta(seconds=5)
                    email.status = 'delivered'

                    # Add opens
                    if scenario in ['high_engagement', 'medium_engagement', 'replied']:
                        email.opened_at = sequence_time + timedelta(minutes=15)
                        email.open_count = 1 + step  # More opens on later emails
                        email.status = 'opened'

                    # Add clicks for high engagement
                    if scenario == 'high_engagement':
                        email.clicked_at = sequence_time + timedelta(minutes=30)
                        email.click_count = 1
                        email.clicked_links = ['https://savety.ai', 'https://marketing.savety.online']
                        email.status = 'clicked'

                    # Add reply for replied scenario (only on first follow-up)
                    if scenario == 'replied' and step == 1:
                        email.replied_at = sequence_time + timedelta(hours=2)
                        email.status = 'replied'
                        status.replied_at = email.replied_at

                elif scenario == 'low_engagement':
                    # Only delivery, no engagement
                    email.delivered_at = sequence_time + timedelta(seconds=8)
                    email.status = 'delivered'

        db.session.commit()
        print("✅ Created email sequences with varied engagement patterns")

        # Display summary
        print("\n📊 TEST DATA SUMMARY:")
        print(f"   • Campaigns: {Campaign.query.filter(Campaign.name.like('%Analytics Test%')).count()}")
        print(f"   • Contacts: {Contact.query.filter(Contact.email.like('%analyticstest%')).count()}")
        print(f"   • Email Sequences: {EmailSequence.query.join(Campaign).filter(Campaign.name.like('%Analytics Test%')).count()}")
        print(f"   • Sent Emails: {Email.query.filter(Email.subject.like('%Test Analytics%')).count()}")

        # Show engagement breakdown
        total_emails = Email.query.filter(Email.subject.like('%Test Analytics%'))
        delivered = total_emails.filter(Email.delivered_at.isnot(None)).count()
        opened = total_emails.filter(Email.opened_at.isnot(None)).count()
        clicked = total_emails.filter(Email.clicked_at.isnot(None)).count()
        replied = total_emails.filter(Email.replied_at.isnot(None)).count()

        print(f"\n📈 ENGAGEMENT METRICS:")
        print(f"   • Delivered: {delivered}")
        print(f"   • Opened: {opened}")
        print(f"   • Clicked: {clicked}")
        print(f"   • Replied: {replied}")

        if delivered > 0:
            print(f"   • Open Rate: {(opened/delivered)*100:.1f}%")
            print(f"   • Click Rate: {(clicked/delivered)*100:.1f}%")
            print(f"   • Reply Rate: {(replied/delivered)*100:.1f}%")


def test_analytics_dashboard():
    """Test the enhanced analytics dashboard"""
    print("\n" + "=" * 70)
    print("TESTING ENHANCED ANALYTICS DASHBOARD")
    print("=" * 70)

    app = create_app()
    with app.app_context():
        # Import and test analytics functions
        from routes.enhanced_analytics import (
            get_enhanced_workflow_stats,
            get_campaigns_with_sequence_metrics,
            get_recent_engagement_timeline,
            get_sequence_step_performance
        )

        print("\n🔍 Testing analytics functions...")

        # Test workflow stats
        print("\n1️⃣ Testing get_enhanced_workflow_stats()...")
        try:
            stats = get_enhanced_workflow_stats()
            print("✅ Workflow stats generated successfully")
            print(f"   • Total contacts: {stats.get('overview', {}).get('total_contacts', 0)}")
            print(f"   • Sent emails: {stats.get('overview', {}).get('sent_emails', 0)}")
            print(f"   • Open rate: {stats.get('engagement', {}).get('open_rate', 0)}%")
            print(f"   • Click rate: {stats.get('engagement', {}).get('click_rate', 0)}%")
        except Exception as e:
            print(f"❌ Error in workflow stats: {e}")

        # Test campaign metrics
        print("\n2️⃣ Testing get_campaigns_with_sequence_metrics()...")
        try:
            campaigns = get_campaigns_with_sequence_metrics()
            print(f"✅ Campaign metrics generated for {len(campaigns)} campaigns")
            for campaign in campaigns:
                print(f"   📢 {campaign['name']}: {len(campaign['sequence_metrics'])} sequence steps")
                for seq in campaign['sequence_metrics']:
                    print(f"      • {seq['name']}: {seq['sent']} sent, {seq['open_rate']}% opened")
        except Exception as e:
            print(f"❌ Error in campaign metrics: {e}")

        # Test engagement timeline
        print("\n3️⃣ Testing get_recent_engagement_timeline()...")
        try:
            timeline = get_recent_engagement_timeline()
            print(f"✅ Engagement timeline generated with {len(timeline)} events")
            for event in timeline[:5]:  # Show first 5
                print(f"   🔔 {event['type'].upper()}: {event['description']}")
        except Exception as e:
            print(f"❌ Error in engagement timeline: {e}")

        # Test sequence performance
        print("\n4️⃣ Testing get_sequence_step_performance()...")
        try:
            performance = get_sequence_step_performance()
            print(f"✅ Sequence performance generated for {len(performance)} steps")
            for step in performance:
                print(f"   📈 {step['name']}: {step['sent']} sent, {step['open_rate']}% opened, {step['click_rate']}% clicked")
        except Exception as e:
            print(f"❌ Error in sequence performance: {e}")


if __name__ == "__main__":
    print("🚀 Starting Enhanced Analytics Dashboard Test")

    try:
        # Step 1: Create test data
        create_test_data_for_analytics()

        # Step 2: Test analytics functions
        test_analytics_dashboard()

        print("\n" + "=" * 70)
        print("✅ ENHANCED ANALYTICS TEST COMPLETED SUCCESSFULLY!")
        print("=" * 70)
        print("\n🌐 You can now visit:")
        print("   • https://marketing.savety.online/sequence-analytics")
        print("   • Or: http://localhost:5000/sequence-analytics")
        print("\n📊 The dashboard will show:")
        print("   • Complete email sequence tracking")
        print("   • Per-email engagement metrics")
        print("   • Clear sequence step identification")
        print("   • Real-time engagement timeline")
        print("   • Campaign-specific performance breakdown")

    except Exception as e:
        print(f"\n❌ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()