"""
Brevo Webhook Handler for Email Events
Handles replies, opens, clicks, bounces to update sequence status
Enhanced with comprehensive event logging and analytics
"""
from flask import Blueprint, request, jsonify
from models.database import db, ContactCampaignStatus, Email, Campaign, Contact, WebhookEvent
from services.webhook_analytics import create_webhook_analytics_service
from datetime import datetime
import logging
import json
import hashlib
import hmac

logger = logging.getLogger(__name__)

webhooks_bp = Blueprint('webhooks', __name__)

@webhooks_bp.route('/webhooks/brevo', methods=['POST'])
def handle_brevo_webhook():
    """
    Handle incoming webhooks from Brevo for email events
    Events: delivered, opened, clicked, replied, bounced, spam, unsubscribed
    """
    try:
        # Get the webhook data
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Log the incoming webhook for debugging
        logger.info(f"Received Brevo webhook: {data.get('event', 'unknown')}")
        
        # Verify webhook signature if secret is configured
        webhook_secret = None
        try:
            from models.database import Settings
            webhook_secret = Settings.get_setting('brevo_webhook_secret', '')
        except:
            pass
        
        if webhook_secret:
            signature = request.headers.get('X-Brevo-Signature', '')
            if not verify_webhook_signature(request.data, signature, webhook_secret):
                logger.warning("Invalid webhook signature")
                return jsonify({'error': 'Invalid signature'}), 401
        
        # Process the event
        event_type = data.get('event', '').lower()
        email_address = data.get('email', '')
        message_id = data.get('message-id', data.get('MessageId', ''))
        
        # Find the contact and their campaign status
        contact = Contact.query.filter_by(email=email_address).first()
        if not contact:
            logger.warning(f"Contact not found for email: {email_address}")
            return jsonify({'status': 'ignored', 'reason': 'contact not found'}), 200
        
        # Find the email record if message ID is provided
        email_record = None
        campaign = None
        if message_id:
            email_record = Email.query.filter_by(brevo_message_id=message_id).first()
            if email_record:
                campaign = Campaign.query.get(email_record.campaign_id)
        
        # Initialize analytics service
        analytics_service = create_webhook_analytics_service()
        
        # Save webhook event for analytics
        webhook_event = analytics_service.save_webhook_event(
            contact=contact,
            email=email_record,
            campaign=campaign,
            event_data=data
        )
        
        # Process based on event type (existing logic)
        if event_type == 'replied' or event_type == 'reply':
            handle_reply_event(contact, data)
        elif event_type == 'opened' or event_type == 'open':
            handle_open_event(contact, data)
        elif event_type == 'clicked' or event_type == 'click':
            handle_click_event(contact, data)
        elif event_type == 'bounced' or event_type == 'bounce':
            handle_bounce_event(contact, data)
        elif event_type == 'unsubscribed' or event_type == 'unsubscribe':
            handle_unsubscribe_event(contact, data)
        elif event_type == 'spam' or event_type == 'complaint':
            handle_spam_event(contact, data)
        elif event_type == 'delivered' or event_type == 'delivery':
            handle_delivery_event(contact, data)
        else:
            logger.info(f"Unhandled event type: {event_type}")
        
        # Commit all database changes including webhook event
        db.session.commit()
        
        response_data = {
            'status': 'success', 
            'event': event_type,
            'contact_email': email_address,
            'webhook_event_id': webhook_event.id if webhook_event else None
        }
        
        return jsonify(response_data), 200
        
    except Exception as e:
        logger.error(f"Error processing Brevo webhook: {str(e)}")
        db.session.rollback()
        return jsonify({'error': 'Internal server error'}), 500

def verify_webhook_signature(payload, signature, secret):
    """Verify the webhook signature from Brevo"""
    expected_sig = hmac.new(
        secret.encode('utf-8'),
        payload,
        hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(expected_sig, signature)

def handle_reply_event(contact, data):
    """
    Handle reply event - STOP the sequence immediately
    This is the most important event for sequence management
    """
    logger.info(f"Processing REPLY event for contact: {contact.email}")
    
    # Find all active campaign statuses for this contact
    active_statuses = ContactCampaignStatus.query.filter_by(
        contact_id=contact.id,
        replied_at=None  # Not already marked as replied
    ).all()
    
    for status in active_statuses:
        # Mark as replied - this stops the sequence
        status.replied_at = datetime.utcnow()
        logger.info(f"Marked contact {contact.email} as replied in campaign {status.campaign_id}")
        
        # Update campaign response count
        campaign = Campaign.query.get(status.campaign_id)
        if campaign:
            campaign.response_count = (campaign.response_count or 0) + 1
    
    # Also mark the contact as responded
    contact.has_responded = True
    contact.responded_at = datetime.utcnow()
    
    # Find and update the specific email if we can
    if 'message-id' in data:
        email = Email.query.filter_by(brevo_message_id=data['message-id']).first()
        if email:
            email.replied_at = datetime.utcnow()
            email.status = 'replied'

def handle_open_event(contact, data):
    """Handle email open event"""
    logger.info(f"Processing OPEN event for contact: {contact.email}")
    
    # Update contact engagement
    contact.last_opened_at = datetime.utcnow()
    contact.total_opens = (contact.total_opens or 0) + 1
    
    # Find and update the specific email
    if 'message-id' in data:
        email = Email.query.filter_by(brevo_message_id=data['message-id']).first()
        if email:
            if not email.opened_at:  # First open
                email.opened_at = datetime.utcnow()
            email.open_count = (email.open_count or 0) + 1
            email.status = 'opened'

def handle_click_event(contact, data):
    """Handle link click event"""
    logger.info(f"Processing CLICK event for contact: {contact.email}")
    
    clicked_url = data.get('link', '')
    
    # Update contact engagement
    contact.last_clicked_at = datetime.utcnow()
    contact.total_clicks = (contact.total_clicks or 0) + 1
    
    # Find and update the specific email
    if 'message-id' in data:
        email = Email.query.filter_by(brevo_message_id=data['message-id']).first()
        if email:
            if not email.clicked_at:  # First click
                email.clicked_at = datetime.utcnow()
            email.click_count = (email.click_count or 0) + 1
            email.status = 'clicked'
            
            # Store clicked links
            clicked_links = email.clicked_links or []
            if clicked_url and clicked_url not in clicked_links:
                clicked_links.append(clicked_url)
                email.clicked_links = clicked_links

def handle_bounce_event(contact, data):
    """Handle email bounce event"""
    logger.info(f"Processing BOUNCE event for contact: {contact.email}")
    
    bounce_type = data.get('bounce_type', 'hard')
    
    # Mark contact as bounced
    contact.email_status = 'bounced'
    contact.bounce_type = bounce_type
    contact.bounced_at = datetime.utcnow()
    
    # Stop all sequences for hard bounces
    if bounce_type == 'hard':
        active_statuses = ContactCampaignStatus.query.filter_by(
            contact_id=contact.id,
            sequence_completed_at=None
        ).all()
        
        for status in active_statuses:
            status.sequence_completed_at = datetime.utcnow()
            status.completion_reason = 'hard_bounce'
    
    # Update email record
    if 'message-id' in data:
        email = Email.query.filter_by(brevo_message_id=data['message-id']).first()
        if email:
            email.bounced_at = datetime.utcnow()
            email.bounce_type = bounce_type
            email.status = 'bounced'

def handle_unsubscribe_event(contact, data):
    """Handle unsubscribe event - stop all sequences"""
    logger.info(f"Processing UNSUBSCRIBE event for contact: {contact.email}")
    
    # Mark contact as unsubscribed
    contact.is_subscribed = False
    contact.unsubscribed_at = datetime.utcnow()
    
    # Stop all active sequences
    active_statuses = ContactCampaignStatus.query.filter_by(
        contact_id=contact.id,
        sequence_completed_at=None
    ).all()
    
    for status in active_statuses:
        status.sequence_completed_at = datetime.utcnow()
        status.completion_reason = 'unsubscribed'
        logger.info(f"Stopped sequence for unsubscribed contact {contact.email} in campaign {status.campaign_id}")

def handle_spam_event(contact, data):
    """Handle spam complaint - stop all sequences and mark contact"""
    logger.info(f"Processing SPAM event for contact: {contact.email}")
    
    # Mark contact as spam reporter
    contact.marked_as_spam = True
    contact.spam_reported_at = datetime.utcnow()
    contact.is_subscribed = False
    
    # Stop all active sequences immediately
    active_statuses = ContactCampaignStatus.query.filter_by(
        contact_id=contact.id,
        sequence_completed_at=None
    ).all()
    
    for status in active_statuses:
        status.sequence_completed_at = datetime.utcnow()
        status.completion_reason = 'spam_complaint'
        logger.info(f"Stopped sequence for spam reporter {contact.email} in campaign {status.campaign_id}")

def handle_delivery_event(contact, data):
    """Handle successful delivery event"""
    logger.info(f"Processing DELIVERY event for contact: {contact.email}")
    
    # Update email record
    if 'message-id' in data:
        email = Email.query.filter_by(brevo_message_id=data['message-id']).first()
        if email:
            email.delivered_at = datetime.utcnow()
            email.status = 'delivered'
    
    # Update contact last contacted time
    contact.last_contacted_at = datetime.utcnow()

# Additional endpoint to manually check reply status
@webhooks_bp.route('/api/check-replies', methods=['POST'])
def check_replies():
    """Manually check and update reply status for a contact"""
    try:
        data = request.get_json()
        email = data.get('email')
        
        if not email:
            return jsonify({'error': 'Email required'}), 400
        
        contact = Contact.query.filter_by(email=email).first()
        if not contact:
            return jsonify({'error': 'Contact not found'}), 404
        
        # Simulate reply detection (in production, this would check email server)
        handle_reply_event(contact, {'email': email})
        db.session.commit()
        
        return jsonify({
            'status': 'success',
            'message': f'Marked {email} as replied',
            'sequences_stopped': True
        }), 200
        
    except Exception as e:
        logger.error(f"Error checking replies: {str(e)}")
        return jsonify({'error': str(e)}), 500

@webhooks_bp.route('/api/simulate-webhook', methods=['POST'])
def simulate_webhook():
    """Simulate a Brevo webhook event for testing purposes"""
    try:
        data = request.get_json()
        event_type = data.get('event', 'delivered')
        email_address = data.get('email', '')
        message_id = data.get('message_id', f'test_{int(datetime.now().timestamp())}')
        
        if not email_address:
            return jsonify({'error': 'Email address required'}), 400
        
        # Create simulated webhook payload
        webhook_data = {
            'event': event_type,
            'email': email_address,
            'message-id': message_id,
            'timestamp': datetime.utcnow().isoformat(),
            'tag': ['campaign'],
            'subject': data.get('subject', 'Test Email')
        }
        
        # Add event-specific data
        if event_type == 'clicked':
            webhook_data['link'] = data.get('link', 'https://example.com')
        elif event_type == 'bounced':
            webhook_data['bounce_type'] = data.get('bounce_type', 'hard')
        
        # Process the simulated webhook
        contact = Contact.query.filter_by(email=email_address).first()
        if not contact:
            return jsonify({'error': 'Contact not found'}), 404
        
        # Process based on event type
        if event_type == 'delivered':
            handle_delivery_event(contact, webhook_data)
        elif event_type == 'opened':
            handle_open_event(contact, webhook_data)
        elif event_type == 'clicked':
            handle_click_event(contact, webhook_data)
        elif event_type == 'replied':
            handle_reply_event(contact, webhook_data)
        elif event_type == 'bounced':
            handle_bounce_event(contact, webhook_data)
        elif event_type == 'unsubscribed':
            handle_unsubscribe_event(contact, webhook_data)
        elif event_type == 'spam':
            handle_spam_event(contact, webhook_data)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'Simulated {event_type} event for {email_address}',
            'webhook_data': webhook_data
        }), 200
        
    except Exception as e:
        logger.error(f"Error simulating webhook: {str(e)}")
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@webhooks_bp.route('/api/webhook-analytics', methods=['GET'])
def get_webhook_analytics():
    """Get email analytics based on webhook events"""
    try:
        days = request.args.get('days', 30, type=int)
        analytics_service = create_webhook_analytics_service()
        analytics = analytics_service.get_email_analytics(days=days)
        
        return jsonify(analytics), 200
        
    except Exception as e:
        logger.error(f"Error getting webhook analytics: {str(e)}")
        return jsonify({'error': str(e)}), 500

@webhooks_bp.route('/api/campaign-analytics/<int:campaign_id>', methods=['GET'])
def get_campaign_webhook_analytics(campaign_id):
    """Get webhook analytics for a specific campaign"""
    try:
        days = request.args.get('days', 30, type=int)
        analytics_service = create_webhook_analytics_service()
        analytics = analytics_service.get_campaign_analytics(campaign_id=campaign_id, days=days)
        
        return jsonify(analytics), 200
        
    except Exception as e:
        logger.error(f"Error getting campaign analytics: {str(e)}")
        return jsonify({'error': str(e)}), 500

@webhooks_bp.route('/api/contact-timeline/<int:contact_id>', methods=['GET'])
def get_contact_webhook_timeline(contact_id):
    """Get webhook event timeline for a specific contact"""
    try:
        days = request.args.get('days', 30, type=int)
        analytics_service = create_webhook_analytics_service()
        timeline = analytics_service.get_contact_timeline(contact_id=contact_id, days=days)
        
        return jsonify({
            'contact_id': contact_id,
            'timeline': timeline,
            'total_events': len(timeline)
        }), 200
        
    except Exception as e:
        logger.error(f"Error getting contact timeline: {str(e)}")
        return jsonify({'error': str(e)}), 500

@webhooks_bp.route('/api/daily-analytics', methods=['GET'])
def get_daily_webhook_analytics():
    """Get day-by-day analytics for dashboard charts"""
    try:
        days = request.args.get('days', 7, type=int)
        analytics_service = create_webhook_analytics_service()
        daily_data = analytics_service.get_daily_analytics(days=days)
        
        return jsonify({
            'period_days': days,
            'daily_data': daily_data
        }), 200
        
    except Exception as e:
        logger.error(f"Error getting daily analytics: {str(e)}")
        return jsonify({'error': str(e)}), 500

@webhooks_bp.route('/api/top-links', methods=['GET'])
def get_top_clicked_links():
    """Get most clicked links from webhook events"""
    try:
        days = request.args.get('days', 30, type=int)
        limit = request.args.get('limit', 10, type=int)
        analytics_service = create_webhook_analytics_service()
        top_links = analytics_service.get_top_clicked_links(days=days, limit=limit)
        
        return jsonify({
            'period_days': days,
            'top_links': top_links
        }), 200
        
    except Exception as e:
        logger.error(f"Error getting top links: {str(e)}")
        return jsonify({'error': str(e)}), 500