#!/usr/bin/env python3
"""
Full Flow Test Script for SalesBreachPro
Tests complete workflow: campaigns -> templates -> contact upload -> breach scan -> email sequences
"""
import sys
import os
import time
import csv
import io
from datetime import datetime, timedelta

# Add the parent directory to Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

from app import create_app
from models.database import (
    db, Contact, Campaign, EmailTemplate, EmailSequence, 
    ContactCampaignStatus, Email, Breach
)
from services.email_sequence_service import EmailSequenceService
from services.background_scanner import start_contact_scan

def create_test_campaigns():
    """Create test campaigns for breached and non-breached contacts"""
    print("\n1. CREATING TEST CAMPAIGNS")
    print("-" * 40)
    
    try:
        # Check if campaigns already exist
        breached_campaign = Campaign.query.filter_by(name="Test Breached Campaign").first()
        secure_campaign = Campaign.query.filter_by(name="Test Secure Campaign").first()
        
        if breached_campaign and secure_campaign:
            print(f"[OK] Campaigns already exist:")
            print(f"  - Breached Campaign ID: {breached_campaign.id}")
            print(f"  - Secure Campaign ID: {secure_campaign.id}")
            return breached_campaign.id, secure_campaign.id
        
        # Create breached campaign
        if not breached_campaign:
            breached_campaign = Campaign(
                name="Test Breached Campaign",
                description="Test campaign for breached contacts",
                status="active",
                template_type="breached",
                sender_email="emily.carter@savety.ai",
                sender_name="Security Team",
                daily_limit=10,
                total_contacts=0,
                response_count=0
            )
            db.session.add(breached_campaign)
        
        # Create secure campaign  
        if not secure_campaign:
            secure_campaign = Campaign(
                name="Test Secure Campaign", 
                description="Test campaign for secure/non-breached contacts",
                status="active",
                template_type="not_breached",
                sender_email="emily.carter@savety.ai",
                sender_name="Security Team",
                daily_limit=10,
                total_contacts=0,
                response_count=0
            )
            db.session.add(secure_campaign)
        
        db.session.commit()
        
        print(f"[OK] Created campaigns successfully:")
        print(f"  - Breached Campaign ID: {breached_campaign.id}")
        print(f"  - Secure Campaign ID: {secure_campaign.id}")
        
        return breached_campaign.id, secure_campaign.id
        
    except Exception as e:
        print(f"[ERROR] Error creating campaigns: {str(e)}")
        return None, None

def create_test_templates():
    """Create email templates with 5-minute delays for testing"""
    print("\n2. CREATING EMAIL TEMPLATES")
    print("-" * 40)
    
    try:
        templates_created = 0
        
        # Templates for BREACHED contacts
        breached_templates = [
            {
                'name': 'Breached Initial Email',
                'risk_level': 'breached',
                'sequence_step': 0,
                'delay_amount': 0,
                'delay_unit': 'minutes',
                'subject_line': '🔴 URGENT: Security Breach Detected for {{domain}}',
                'email_body': '''<p>Hello {{first_name}},</p>

<p><strong>URGENT SECURITY ALERT</strong></p>

<p>Our security scan has detected that your domain <strong>{{domain}}</strong> appears in breach databases with credential exposures.</p>

<p>This is our initial contact to inform you of this critical security issue.</p>

<p>Best regards,<br>Security Team</p>'''
            },
            {
                'name': 'Breached Follow-up 1',
                'risk_level': 'breached', 
                'sequence_step': 1,
                'delay_amount': 5,
                'delay_unit': 'minutes',
                'subject_line': '🔴 URGENT: Security Breach Detected for {{domain}}',
                'email_body': '''<p>Hello {{first_name}},</p>

<p>This is a follow-up to our previous security alert regarding your domain <strong>{{domain}}</strong>.</p>

<p>We haven't heard back from you yet regarding the credential exposure we detected.</p>

<p>Please respond to confirm you've received this alert.</p>

<p>Best regards,<br>Security Team</p>'''
            },
            {
                'name': 'Breached Follow-up 2',
                'risk_level': 'breached',
                'sequence_step': 2, 
                'delay_amount': 5,
                'delay_unit': 'minutes',
                'subject_line': '🔴 URGENT: Security Breach Detected for {{domain}}',
                'email_body': '''<p>Hello {{first_name}},</p>

<p>This is our final follow-up regarding the security breach detected for <strong>{{domain}}</strong>.</p>

<p>Immediate action is required to secure your credentials.</p>

<p>Please contact us immediately.</p>

<p>Best regards,<br>Security Team</p>'''
            }
        ]
        
        # Templates for NOT BREACHED contacts  
        secure_templates = [
            {
                'name': 'Secure Initial Email',
                'risk_level': 'not_breached',
                'sequence_step': 0,
                'delay_amount': 0, 
                'delay_unit': 'minutes',
                'subject_line': '🛡️ Security Status: {{domain}} is Secure',
                'email_body': '''<p>Hello {{first_name}},</p>

<p>Good news! Our security scan shows that <strong>{{domain}}</strong> does not appear in any known breach databases.</p>

<p>However, we'd like to share some proactive security recommendations.</p>

<p>Best regards,<br>Security Team</p>'''
            },
            {
                'name': 'Secure Follow-up 1',
                'risk_level': 'not_breached',
                'sequence_step': 1,
                'delay_amount': 5,
                'delay_unit': 'minutes', 
                'subject_line': '🛡️ Security Status: {{domain}} is Secure',
                'email_body': '''<p>Hello {{first_name}},</p>

<p>Following up on our previous message about <strong>{{domain}}</strong>'s secure status.</p>

<p>Would you be interested in learning more about proactive security measures?</p>

<p>Best regards,<br>Security Team</p>'''
            }
        ]
        
        # Create breached templates
        for template_data in breached_templates:
            existing = EmailTemplate.query.filter_by(name=template_data['name']).first()
            if not existing:
                template = EmailTemplate(
                    name=template_data['name'],
                    risk_level=template_data['risk_level'],
                    sequence_step=template_data['sequence_step'],
                    delay_amount=template_data['delay_amount'],
                    delay_unit=template_data['delay_unit'],
                    subject_line=template_data['subject_line'],
                    email_body=template_data['email_body'],
                    active=True,
                    template_type='sequence'
                )
                db.session.add(template)
                templates_created += 1
                print(f"[OK] Created: {template_data['name']}")
            else:
                print(f"• Exists: {template_data['name']}")
        
        # Create secure templates
        for template_data in secure_templates:
            existing = EmailTemplate.query.filter_by(name=template_data['name']).first()
            if not existing:
                template = EmailTemplate(
                    name=template_data['name'],
                    risk_level=template_data['risk_level'],
                    sequence_step=template_data['sequence_step'], 
                    delay_amount=template_data['delay_amount'],
                    delay_unit=template_data['delay_unit'],
                    subject_line=template_data['subject_line'],
                    email_body=template_data['email_body'],
                    active=True,
                    template_type='sequence'
                )
                db.session.add(template)
                templates_created += 1
                print(f"[OK] Created: {template_data['name']}")
            else:
                print(f"• Exists: {template_data['name']}")
        
        db.session.commit()
        print(f"\n[OK] Template creation complete ({templates_created} new templates)")
        return True
        
    except Exception as e:
        print(f"[ERROR] Error creating templates: {str(e)}")
        return False

def upload_test_contact():
    """Upload test contact info@moaz.ca"""
    print("\n3. UPLOADING TEST CONTACT")
    print("-" * 40)
    
    try:
        # Check if contact already exists
        existing_contact = Contact.query.filter_by(email="info@moaz.ca").first()
        
        if existing_contact:
            print(f"[OK] Test contact already exists (ID: {existing_contact.id})")
            print(f"  Email: {existing_contact.email}")
            print(f"  Domain: {existing_contact.domain}")
            print(f"  Breach Status: {existing_contact.breach_status}")
            return existing_contact.id
        
        # Create new contact
        contact = Contact(
            email="info@moaz.ca",
            domain="moaz.ca",
            first_name="Test",
            last_name="Contact",
            company="Moaz Test Company",
            breach_status="unknown",
            risk_score=0.0,
            is_active=True
        )
        
        db.session.add(contact)
        db.session.commit()
        
        print(f"[OK] Created test contact (ID: {contact.id})")
        print(f"  Email: {contact.email}")
        print(f"  Domain: {contact.domain}")
        
        return contact.id
        
    except Exception as e:
        print(f"[ERROR] Error uploading contact: {str(e)}")
        return None

def trigger_breach_scan(contact_id):
    """Trigger breach scan for the test contact"""
    print("\n4. TRIGGERING BREACH SCAN")
    print("-" * 40)
    
    try:
        contact = Contact.query.get(contact_id)
        if not contact:
            print(f"[ERROR] Contact {contact_id} not found")
            return None
        
        print(f"Starting FlawTrack breach scan for {contact.email}...")
        
        # Start background breach scan
        job_id = start_contact_scan([contact_id])
        print(f"[OK] Breach scan started (Job ID: {job_id})")
        
        # Wait for scan to complete (check every 10 seconds, max 2 minutes)
        max_wait_time = 120  # 2 minutes
        check_interval = 10   # 10 seconds
        elapsed_time = 0
        
        print("Waiting for breach scan to complete...")
        
        while elapsed_time < max_wait_time:
            time.sleep(check_interval)
            elapsed_time += check_interval
            
            # Refresh contact from database
            db.session.refresh(contact)
            
            if contact.breach_status != 'unknown':
                print(f"[OK] Breach scan completed!")
                print(f"  Domain: {contact.domain}")
                print(f"  Breach Status: {contact.breach_status}")
                
                # Check breach details
                breach = Breach.query.filter_by(domain=contact.domain).first()
                if breach:
                    print(f"  Records Affected: {breach.records_affected}")
                    print(f"  Last Updated: {breach.last_updated}")
                
                return contact.breach_status
            
            print(f"  Still scanning... ({elapsed_time}s elapsed)")
        
        print(f"⚠ Breach scan timeout after {max_wait_time}s")
        return "unknown"
        
    except Exception as e:
        print(f"[ERROR] Error during breach scan: {str(e)}")
        return None

def enroll_contact_in_campaign(contact_id, breach_status, breached_campaign_id, secure_campaign_id):
    """Enroll contact in appropriate campaign based on breach status"""
    print("\n5. ENROLLING CONTACT IN CAMPAIGN")
    print("-" * 40)
    
    try:
        contact = Contact.query.get(contact_id)
        if not contact:
            print(f"[ERROR] Contact {contact_id} not found")
            return False
        
        # Determine which campaign to use based on breach status
        if breach_status == 'breached':
            campaign_id = breached_campaign_id
            campaign_name = "Breached Campaign"
        else:
            campaign_id = secure_campaign_id  
            campaign_name = "Secure Campaign"
        
        print(f"Enrolling {contact.email} in {campaign_name}...")
        print(f"  Breach Status: {breach_status}")
        print(f"  Campaign ID: {campaign_id}")
        
        # Clear any existing enrollment for testing purposes
        from models.database import ContactCampaignStatus, EmailSequence
        
        existing_enrollment = ContactCampaignStatus.query.filter_by(
            contact_id=contact_id, 
            campaign_id=campaign_id
        ).first()
        
        if existing_enrollment:
            print("  Clearing existing enrollment for fresh test...")
            # Delete existing email sequences
            EmailSequence.query.filter_by(
                contact_id=contact_id,
                campaign_id=campaign_id
            ).delete()
            
            # Delete enrollment status
            db.session.delete(existing_enrollment)
            db.session.commit()
            print("  [OK] Existing enrollment cleared")
        
        # Initialize email sequence service
        sequence_service = EmailSequenceService()
        
        # Enroll contact in campaign
        result = sequence_service.enroll_contact_in_campaign(
            contact_id=contact_id,
            campaign_id=campaign_id,
            force_breach_check=False  # We already scanned
        )
        
        if result['success']:
            print(f"[OK] Contact enrolled successfully!")
            print(f"  Emails scheduled: {result.get('emails_scheduled', 0)}")
            
            # Show scheduled emails
            sequences = EmailSequence.query.filter_by(
                contact_id=contact_id,
                campaign_id=campaign_id
            ).order_by(EmailSequence.sequence_step).all()
            
            print(f"\nScheduled Email Sequence:")
            for seq in sequences:
                print(f"  Step {seq.sequence_step}: {seq.scheduled_datetime}")
            
            return True
        else:
            print(f"[ERROR] Enrollment failed: {result.get('error', 'Unknown error')}")
            return False
            
    except Exception as e:
        print(f"[ERROR] Error enrolling contact: {str(e)}")
        return False

def monitor_email_sequence(contact_id):
    """Monitor the email sequence progress"""
    print("\n6. MONITORING EMAIL SEQUENCE")
    print("-" * 40)
    
    try:
        # Monitor for 20 minutes (enough for initial + 2 follow-ups with 5min delays)
        max_monitor_time = 1200  # 20 minutes
        check_interval = 30      # 30 seconds
        elapsed_time = 0
        
        print("Monitoring email sequence progress...")
        print("(Initial email should send immediately, follow-ups every 5 minutes)")
        
        sent_emails = []
        
        while elapsed_time < max_monitor_time:
            # Check for sent emails
            emails = Email.query.filter_by(contact_id=contact_id).all()
            
            new_emails = [e for e in emails if e.id not in [se.id for se in sent_emails]]
            
            for email in new_emails:
                sent_emails.append(email)
                print(f"\n[EMAIL] EMAIL SENT (ID: {email.id})")
                print(f"  Subject: {email.subject}")
                print(f"  Status: {email.status}")
                print(f"  Sent At: {email.sent_at}")
                print(f"  Brevo Message ID: {email.brevo_message_id}")
                print(f"  Thread Message ID: {email.thread_message_id}")
                
                if email.thread_message_id and len(sent_emails) > 1:
                    print(f"  [EMAIL] THREADING: This email is threaded with previous emails")
            
            # Check sequence status
            sequences = EmailSequence.query.filter_by(contact_id=contact_id).all()
            pending = [s for s in sequences if s.status == 'scheduled']
            sent = [s for s in sequences if s.status == 'sent']
            
            print(f"\nSequence Status: {len(sent)} sent, {len(pending)} pending")
            
            if len(pending) == 0:
                print(f"[OK] All emails in sequence completed!")
                break
            
            time.sleep(check_interval)
            elapsed_time += check_interval
            
            if elapsed_time % 60 == 0:  # Every minute
                print(f"  Monitoring... ({elapsed_time//60} minutes elapsed)")
        
        print(f"\nFinal Results:")
        print(f"  Total emails sent: {len(sent_emails)}")
        
        if sent_emails:
            print(f"\nEmail Threading Test:")
            initial_email = sent_emails[0]
            print(f"  Initial email thread ID: {initial_email.thread_message_id}")
            
            for i, email in enumerate(sent_emails[1:], 1):
                print(f"  Follow-up {i}: Uses thread ID from initial email for threading")
        
        return True
        
    except Exception as e:
        print(f"[ERROR] Error monitoring sequence: {str(e)}")
        return False

def main():
    """Main test function"""
    print("SALESBREACHPRO FULL FLOW TEST")
    print("=" * 60)
    print("Testing: Campaigns -> Templates -> Contact -> Scan -> Sequence -> Threading")
    print("Email Delays: 5 minutes between emails for testing")
    print("=" * 60)
    
    try:
        app = create_app()
        
        with app.app_context():
            # Step 1: Create campaigns
            breached_campaign_id, secure_campaign_id = create_test_campaigns()
            if not breached_campaign_id or not secure_campaign_id:
                print("[ERROR] Failed to create campaigns. Aborting test.")
                return False
            
            # Step 2: Create email templates
            if not create_test_templates():
                print("[ERROR] Failed to create templates. Aborting test.")
                return False
            
            # Step 3: Upload test contact
            contact_id = upload_test_contact()
            if not contact_id:
                print("[ERROR] Failed to upload contact. Aborting test.")
                return False
            
            # Step 4: Trigger breach scan
            breach_status = trigger_breach_scan(contact_id)
            if not breach_status:
                print("[ERROR] Failed to complete breach scan. Aborting test.")
                return False
            
            # Step 5: Enroll contact in appropriate campaign
            if not enroll_contact_in_campaign(contact_id, breach_status, 
                                            breached_campaign_id, secure_campaign_id):
                print("[ERROR] Failed to enroll contact. Aborting test.")
                return False
            
            # Step 6: Monitor email sequence
            monitor_email_sequence(contact_id)
            
            print("\n" + "=" * 60)
            print("[SUCCESS] FULL FLOW TEST COMPLETED SUCCESSFULLY!")
            print("[SUCCESS] Email threading is now implemented:")
            print("   - Follow-up emails will appear in same thread")
            print("   - Subject lines will have 'Re:' prefix")  
            print("   - Proper In-Reply-To and References headers")
            print("=" * 60)
            
            return True
            
    except Exception as e:
        print(f"\n[ERROR] Test failed with error: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    main()