import requests
import json
import time
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from models.database import db, Breach
import logging

logger = logging.getLogger(__name__)

class FlawTrackAPI:
    """FlawTrack API integration for breach data retrieval and risk scoring"""
    
    def __init__(self, api_key: str, endpoint: str):
        self.api_key = api_key
        self.endpoint = endpoint
        self.session = requests.Session()
        self.session.headers.update({
            'Authorization': f'Api-Key {api_key}',
            'Content-Type': 'application/json'
        })
        
    def get_breach_data(self, domain: str) -> Optional[Dict]:
        """Get breach data for a single domain from FlawTrack API"""
        # Check if FlawTrack scanning is disabled
        scanning_enabled = os.environ.get('FLAWTRACK_SCANNING_ENABLED', 'true').lower() == 'true'
        
        if not scanning_enabled:
            logger.info(f"FlawTrack scanning disabled for {domain} - returning None to mark as unknown")
            return None  # This will cause the contact to be marked as 'unknown'
        
        try:
            response = self.session.get(
                self.endpoint,
                params={'query': domain},
                timeout=30  # Increased timeout for production API
            )
            
            if response.status_code == 200:
                data = response.json()
                if isinstance(data, list):
                    logger.info(f"FlawTrack API success for {domain}: found {len(data)} credential records")
                    return data if len(data) > 0 else []
                else:
                    logger.info(f"FlawTrack API success for {domain}: found breach data")
                    return data
            elif response.status_code == 404:
                logger.info(f"FlawTrack API: No breaches found for {domain}")
                return []  # Empty list means no breaches
            else:
                logger.warning(f"FlawTrack API returned {response.status_code} for {domain}")
                return None
                
        except requests.exceptions.RequestException as e:
            logger.warning(f"FlawTrack API failed for {domain}: {str(e)}")
            return None
    
    def _get_demo_breach_data(self, domain: str) -> Dict:
        """Generate demo breach data for testing"""
        import hashlib
        
        # Create consistent "random" results based on domain hash
        domain_hash = int(hashlib.md5(domain.encode()).hexdigest()[:8], 16)
        
        # Demo domains with different scenarios
        if any(test_domain in domain.lower() for test_domain in ['gmail', 'yahoo', 'hotmail', 'outlook']):
            # Popular email providers - high risk
            return {
                'found': True,
                'breaches': [
                    {
                        'name': f'{domain} - 2023 Data Breach',
                        'date': '2023-06-15',
                        'records': 2500000 + (domain_hash % 1000000),
                        'data_classes': ['Email addresses', 'Passwords', 'Names', 'Phone numbers'],
                        'verified': True
                    }
                ]
            }
        elif any(test_domain in domain.lower() for test_domain in ['company', 'corp', 'business', 'enterprise']):
            # Business domains - medium risk
            return {
                'found': True, 
                'breaches': [
                    {
                        'name': f'{domain} - Employee Data Leak',
                        'date': '2022-03-20',
                        'records': 50000 + (domain_hash % 100000),
                        'data_classes': ['Email addresses', 'Names', 'Job titles'],
                        'verified': True
                    }
                ]
            }
        elif domain_hash % 3 == 0:
            # 1/3 of domains have breaches (random based on hash)
            return {
                'found': True,
                'breaches': [
                    {
                        'name': f'{domain} - Security Incident',
                        'date': '2023-01-10', 
                        'records': 10000 + (domain_hash % 50000),
                        'data_classes': ['Email addresses', 'Passwords'],
                        'verified': True
                    }
                ]
            }
        else:
            # Clean domain - no breaches
            return {
                'found': False,
                'breaches': []
            }
    
    def batch_domain_lookup(self, domains: List[str], delay: float = 1.0, progress_callback=None) -> Dict[str, Dict]:
        """Process multiple domains with rate limiting"""
        results = {}
        
        for i, domain in enumerate(domains):
            logger.info(f"Processing domain {i+1}/{len(domains)}: {domain}")
            
            # Update progress callback
            if progress_callback:
                scan_progress = 50 + (i / len(domains)) * 20  # 50-70% range
                progress_callback(f"Scanning {domain} for breaches...", scan_progress, 
                                domains_scanned=i, total_domains=len(domains), current_domain=domain)
            
            # Skip cache for now to avoid app context issues in testing
            # cached_breach = self.get_cached_breach_data(domain)
            # if cached_breach:
            #     results[domain] = cached_breach.to_dict()
            #     continue
            
            # Fetch from API
            breach_data = self.get_breach_data(domain)
            
            if breach_data is not None:
                # API succeeded - process the data
                risk_score = self.calculate_risk_score(breach_data)
                processed_data = self.process_breach_data(domain, breach_data, risk_score)
                results[domain] = processed_data
                
                # Skip caching for now to avoid app context issues in testing
                # self.cache_breach_data(domain, processed_data)
                
            else:
                # API failed or timed out - mark as unknown
                logger.warning(f"FlawTrack API failed for {domain} - marking as unknown")
                results[domain] = {
                    'domain': domain,
                    'breach_name': f"{domain} - Scan Incomplete",
                    'breach_year': None,
                    'records_affected': 0,
                    'data_types': "FlawTrack API unavailable - manual verification needed",
                    'risk_score': 0.0,
                    'severity': 'low',
                    'breach_status': 'unknown',
                    'raw_data': '{}'
                }
            
            # Rate limiting
            if i < len(domains) - 1:
                time.sleep(delay)
        
        return results
    
    def calculate_risk_score(self, breach_data: Dict) -> float:
        """No risk scoring needed - always return 0.0"""
        return 0.0
    
    def calculate_recency_score(self, breach_data: Dict) -> float:
        """Calculate recency score (0-4 points)"""
        # Extract year from breach data (adapt based on FlawTrack response format)
        breach_year = self.extract_breach_year(breach_data)
        
        if not breach_year:
            return 0.0
        
        current_year = datetime.now().year
        years_ago = current_year - breach_year
        
        if years_ago <= 1:
            return 4.0  # Very recent
        elif years_ago <= 2:
            return 3.0  # Recent
        elif years_ago <= 3:
            return 2.0  # Somewhat recent
        elif years_ago <= 5:
            return 1.0  # Older but relevant
        else:
            return 0.0  # Too old
    
    def calculate_impact_score(self, breach_data: Dict) -> float:
        """Calculate impact score based on records affected (0-3 points)"""
        records_affected = self.extract_records_affected(breach_data)
        
        if not records_affected:
            return 1.0  # Default score if unknown
        
        if records_affected >= 1000000:  # 1M+ records
            return 3.0
        elif records_affected >= 100000:  # 100K+ records
            return 2.5
        elif records_affected >= 10000:   # 10K+ records
            return 2.0
        elif records_affected >= 1000:    # 1K+ records
            return 1.5
        else:
            return 1.0
    
    def calculate_severity_score(self, breach_data: Dict) -> float:
        """Calculate severity score based on data types (0-3 points)"""
        data_types = self.extract_data_types(breach_data)
        
        if not data_types:
            return 1.0
        
        data_types_lower = data_types.lower()
        score = 0.0
        
        # High value data types
        high_risk_types = ['password', 'credit card', 'ssn', 'social security', 'financial']
        medium_risk_types = ['email', 'phone', 'address', 'name']
        
        for risk_type in high_risk_types:
            if risk_type in data_types_lower:
                score += 0.8
        
        for risk_type in medium_risk_types:
            if risk_type in data_types_lower:
                score += 0.3
        
        return min(3.0, score)
    
    def extract_breach_year(self, breach_data) -> Optional[int]:
        """Extract breach year from FlawTrack API response"""
        try:
            # FlawTrack format: 'created_at': '2024-08-02T01:56:08.653348Z'
            if isinstance(breach_data, dict) and 'created_at' in breach_data:
                created_at = breach_data['created_at']
                if created_at:
                    # Extract year from ISO datetime string
                    return int(created_at[:4])
            elif isinstance(breach_data, dict) and 'date' in breach_data:
                date_str = breach_data['date']
                return int(date_str[:4]) if len(date_str) >= 4 else None
            elif isinstance(breach_data, dict) and 'year' in breach_data:
                return int(breach_data['year'])
            else:
                return datetime.now().year - 1  # Default to last year
        except (ValueError, TypeError):
            return datetime.now().year - 1
    
    def extract_records_affected(self, breach_data: Dict) -> Optional[int]:
        """Extract number of records affected"""
        try:
            if 'records_affected' in breach_data:
                return int(breach_data['records_affected'])
            elif 'count' in breach_data:
                return int(breach_data['count'])
            else:
                return 10000  # Default estimate
        except (ValueError, TypeError):
            return None
    
    def extract_data_types(self, breach_data: Dict) -> str:
        """Extract data types from breach information"""
        if 'data_types' in breach_data:
            return str(breach_data['data_types'])
        elif 'description' in breach_data:
            return str(breach_data['description'])
        else:
            return "email addresses and user data"
    
    def process_breach_data(self, domain: str, raw_data) -> Dict:
        """Process FlawTrack data into 3 simple statuses: breached, not_breached, unknown"""
        # Handle FlawTrack API format: list of credential records
        if isinstance(raw_data, list):
            if len(raw_data) > 0:
                # Found breaches - extract useful data for campaigns
                first_record = raw_data[0]
                breach_year = self._extract_year_from_created_at(first_record.get('created_at'))
                records_affected = len(raw_data)
                
                # Get sample credentials for campaign use (first few records)
                sample_records = raw_data[:3]  # Get up to 3 sample records
                
                # Aggregate service names
                services = set()
                for record in raw_data:
                    service = record.get('service_name', '')
                    if service:
                        services.add(service)
                
                service_names = list(services)[:5]  # Top 5 services
                
                return {
                    'domain': domain,
                    'breach_status': 'breached',
                    'records_affected': records_affected,
                    'breach_year': breach_year,
                    'services_affected': service_names,
                    'sample_records': sample_records,  # For campaign personalization
                    'breach_data': raw_data,  # Full data stored for reference
                    'risk_score': 0.0,  # Not used
                    'severity': 'unknown'  # Not used
                }
            else:
                # Empty list = no breaches found
                return {
                    'domain': domain,
                    'breach_status': 'not_breached',
                    'records_affected': 0,
                    'breach_year': None,
                    'services_affected': [],
                    'sample_records': [],
                    'breach_data': [],
                    'risk_score': 0.0,
                    'severity': 'unknown'
                }
        
        elif raw_data is None:
            # API failed or timed out
            return {
                'domain': domain,
                'breach_status': 'unknown',  # Didn't scan
                'records_affected': 0,
                'breach_year': None,
                'services_affected': [],
                'sample_records': [],
                'breach_data': None,
                'risk_score': 0.0,
                'severity': 'unknown'
            }
        
        else:
            # Unexpected format - treat as scan failure
            return {
                'domain': domain,
                'breach_status': 'unknown',
                'records_affected': 0,
                'breach_year': None,
                'services_affected': [],
                'sample_records': [],
                'breach_data': raw_data,
                'risk_score': 0.0,
                'severity': 'unknown'
            }
    
    def _extract_year_from_created_at(self, created_at_str: str) -> Optional[int]:
        """Extract year from FlawTrack created_at timestamp like '2024-08-02T01:56:08.653348Z'"""
        if not created_at_str:
            return None
        try:
            return int(created_at_str.split('-')[0])
        except (ValueError, IndexError, AttributeError):
            return None
    
    def _extract_year_from_date(self, date_str: str) -> Optional[int]:
        """Extract year from date string like '2023-06-15'"""
        if not date_str:
            return None
        try:
            return int(date_str.split('-')[0])
        except (ValueError, IndexError):
            return None
    
    def get_severity_category(self, risk_score: float) -> str:
        """Convert risk score to severity category"""
        if risk_score >= 7.0:
            return 'high'
        elif risk_score >= 4.0:
            return 'medium'
        else:
            return 'low'
    
    def _classify_domain_intelligently(self, domain: str) -> Dict:
        """
        Intelligently classify domains based on reputation and common patterns
        """
        domain_lower = domain.lower()
        
        # Known secure/major providers (very unlikely to be breached in our context)
        major_providers = {
            'gmail.com', 'outlook.com', 'hotmail.com', 'yahoo.com', 'icloud.com',
            'protonmail.com', 'aol.com', 'live.com', 'msn.com', 'me.com'
        }
        
        # Enterprise/corporate domains (less likely to be breached)
        enterprise_indicators = [
            'microsoft.com', 'google.com', 'apple.com', 'amazon.com', 'facebook.com',
            'twitter.com', 'linkedin.com', 'salesforce.com', 'oracle.com', 'ibm.com',
            'cisco.com', 'intel.com', 'adobe.com', 'netflix.com', 'dropbox.com'
        ]
        
        # Government domains (secure)
        gov_tlds = ['.gov', '.edu', '.mil']
        
        # Suspicious patterns (more likely to be breached)
        suspicious_patterns = [
            'temp', 'test', 'demo', 'fake', 'sample', 'throwaway', 
            '10minutemail', 'guerrillamail', 'mailinator'
        ]
        
        # Classification logic
        if domain_lower in major_providers:
            status = 'not_breached'
            risk_score = 2.0
            reason = "Major email provider - typically secure"
            
        elif any(domain_lower.endswith(tld) for tld in gov_tlds):
            status = 'not_breached'
            risk_score = 1.0
            reason = "Government/educational domain - highly secure"
            
        elif any(enterprise in domain_lower for enterprise in enterprise_indicators):
            status = 'not_breached'
            risk_score = 2.5
            reason = "Major enterprise domain - well-protected"
            
        elif any(suspicious in domain_lower for suspicious in suspicious_patterns):
            status = 'breached'
            risk_score = 8.0
            reason = "Suspicious domain pattern - high risk"
            
        elif domain_lower.count('.') > 2:  # Subdomain depth might indicate complexity
            status = 'unknown'
            risk_score = 5.0
            reason = "Complex domain structure - needs verification"
            
        elif len(domain_lower.split('.')[0]) < 4:  # Very short domain names
            status = 'unknown'  
            risk_score = 6.0
            reason = "Short domain name - needs manual verification"
            
        else:
            # Default for business domains - assume needs review but not automatically breached
            status = 'unknown'
            risk_score = 5.0
            reason = "Standard business domain - manual verification recommended"
        
        return {
            'domain': domain,
            'breach_name': f"{domain} - {reason}",
            'breach_year': 2024 if status == 'breached' else None,
            'records_affected': 1000 if status == 'breached' else 0,
            'data_types': reason,
            'risk_score': risk_score,
            'severity': self.get_severity_category(risk_score),
            'breach_status': status,
            'raw_data': '{}'
        }
    
    def cache_breach_data(self, domain: str, processed_data: Dict):
        """Cache breach data in database"""
        try:
            # Check if breach already exists
            existing_breach = Breach.query.filter_by(domain=domain).first()
            
            if existing_breach:
                # Update existing record  
                existing_breach.breach_name = f"{domain} Credential Breach"
                existing_breach.breach_year = processed_data.get('breach_year', 2024)
                existing_breach.records_affected = processed_data.get('records_affected', 0)
                existing_breach.data_types = "Credentials, Email addresses"
                existing_breach.risk_score = 0.0
                existing_breach.severity = processed_data.get('severity', 'unknown')
                existing_breach.last_updated = datetime.utcnow()
            else:
                # Create new record
                breach = Breach(
                    domain=domain,
                    breach_name=f"{domain} Credential Breach",
                    breach_year=processed_data.get('breach_year', 2024),
                    records_affected=processed_data.get('records_affected', 0),
                    data_types="Credentials, Email addresses",
                    risk_score=0.0,
                    severity=processed_data.get('severity', 'unknown'),
                    last_updated=datetime.utcnow()
                )
                db.session.add(breach)
            
            db.session.commit()
            logger.info(f"Cached breach data for {domain}")
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error caching breach data for {domain}: {str(e)}")
    
    def get_cached_breach_data(self, domain: str, max_age_days: int = 30) -> Optional[Breach]:
        """Get cached breach data if not stale"""
        try:
            cutoff_date = datetime.utcnow() - timedelta(days=max_age_days)
            breach = Breach.query.filter(
                Breach.domain == domain,
                Breach.last_updated >= cutoff_date
            ).first()
            
            if breach:
                logger.info(f"Using cached breach data for {domain}")
                return breach
            else:
                logger.info(f"No valid cached data found for {domain}")
                return None
                
        except Exception as e:
            logger.error(f"Error retrieving cached breach data for {domain}: {str(e)}")
            return None
    
    def extract_breach_samples(self, raw_data, max_samples: int = 3, redaction_level: str = 'medium') -> List[str]:
        """Extract redacted sample credentials from breach data for email templates"""
        try:
            samples = []
            
            if isinstance(raw_data, list) and len(raw_data) > 0:
                # Extract samples from list of breach records
                for record in raw_data[:max_samples]:
                    email = record.get('email', '')
                    username = record.get('username', '')
                    service = record.get('service_name', '')
                    
                    # Prioritize email, fallback to username
                    credential = email if email else username
                    
                    if credential:
                        redacted = self._redact_credential(credential, redaction_level)
                        if service:
                            samples.append(f"{redacted} ({service})")
                        else:
                            samples.append(redacted)
                            
            elif isinstance(raw_data, dict):
                # Single breach record
                email = raw_data.get('email', '')
                if email:
                    redacted = self._redact_credential(email, redaction_level)
                    samples.append(redacted)
            
            return samples[:max_samples]
            
        except Exception as e:
            logger.error(f"Error extracting breach samples: {str(e)}")
            return []
    
    def _redact_credential(self, credential: str, redaction_level: str = 'medium') -> str:
        """Redact credential for privacy protection"""
        try:
            if '@' in credential:  # Email address
                local, domain = credential.split('@', 1)
                
                if redaction_level == 'full':
                    # Show only first character and domain: j***@company.com
                    redacted_local = local[0] + '***' if len(local) > 0 else '***'
                elif redaction_level == 'medium':
                    # Show first 2 chars and last char: jo***n@company.com
                    if len(local) <= 3:
                        redacted_local = local[0] + '***'
                    else:
                        redacted_local = local[:2] + '***' + local[-1]
                elif redaction_level == 'minimal':
                    # Show first half: john***@company.com
                    mid_point = len(local) // 2
                    redacted_local = local[:mid_point] + '***'
                else:
                    redacted_local = local[0] + '***'
                
                return f"{redacted_local}@{domain}"
            else:
                # Username without @ symbol
                if redaction_level == 'full':
                    return credential[0] + '***' if len(credential) > 0 else '***'
                elif redaction_level == 'medium':
                    if len(credential) <= 3:
                        return credential[0] + '***'
                    else:
                        return credential[:2] + '***' + credential[-1]
                elif redaction_level == 'minimal':
                    mid_point = len(credential) // 2
                    return credential[:mid_point] + '***'
                else:
                    return credential[0] + '***'
                    
        except Exception as e:
            logger.error(f"Error redacting credential: {str(e)}")
            return "***@***.com"

    def get_breach_summary_for_email(self, domain: str) -> Dict:
        """Get breach summary formatted for email templates"""
        breach = Breach.query.filter_by(domain=domain).first()
        
        if not breach:
            return {
                'has_breach': False,
                'risk_level': 'low',
                'template_vars': {}
            }
        
        # Extract breach samples from raw data
        try:
            import json
            import os
            
            # Check if breach samples are enabled
            breach_sample_enabled = os.environ.get('BREACH_SAMPLE_ENABLED', 'true').lower() == 'true'
            
            if breach_sample_enabled:
                redaction_level = os.environ.get('BREACH_SAMPLE_REDACTION_LEVEL', 'medium')
                max_samples = int(os.environ.get('BREACH_SAMPLE_MAX_SAMPLES', '3'))
                
                raw_data = json.loads(breach.breach_data) if breach.breach_data else {}
                breach_samples = self.extract_breach_samples(raw_data, max_samples=max_samples, redaction_level=redaction_level)
                
                # Format samples for email display
                if breach_samples:
                    formatted_samples = "Sample exposed credentials:\n" + "\n".join([f"• {sample}" for sample in breach_samples])
                else:
                    formatted_samples = "Contact us for specific breach details"
            else:
                formatted_samples = "Contact us for specific breach details"
                
        except Exception as e:
            logger.error(f"Error processing breach samples for {domain}: {str(e)}")
            formatted_samples = "Contact us for specific breach details"
        
        return {
            'has_breach': True,
            'risk_level': breach.severity,
            'risk_score': breach.risk_score,
            'template_vars': {
                'breach_name': breach.breach_name,
                'breach_year': breach.breach_year,
                'records_affected': f"{breach.records_affected:,}" if breach.records_affected else "thousands of",
                'data_types': breach.data_types or "user credentials and personal information",
                'breach_sample': formatted_samples
            }
        }