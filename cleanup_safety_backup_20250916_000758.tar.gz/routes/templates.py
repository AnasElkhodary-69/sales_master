from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for
from models.database import db, EmailTemplate, FollowUpSequence, Settings
from datetime import datetime
import json

# Create templates blueprint
templates_bp = Blueprint('templates', __name__, url_prefix='/templates')

@templates_bp.route('/')
def templates():
    """Template management page"""
    templates = EmailTemplate.query.filter_by(active=True).all()
    sequences = FollowUpSequence.query.filter_by(active=True).all()
    return render_template('templates_management.html',
                         templates=templates,
                         sequences=sequences)

@templates_bp.route('/create', methods=['GET', 'POST'])
def create_template():
    """Create new email template"""
    if request.method == 'POST':
        try:
            sequence_order = request.form.get('sequence_order', 1)
            sequence_step = int(sequence_order) - 1
            print(f"DEBUG CREATE TEMPLATE: sequence_order={sequence_order}, sequence_step={sequence_step}")
            
            template = EmailTemplate(
                name=request.form['name'],
                template_type=request.form['template_type'],
                risk_level=request.form['breach_status'],  # Map breach_status to risk_level for backward compatibility
                sequence_step=sequence_step,  # Convert 1-based UI to 0-based sequence
                breach_template_type=request.form.get('breach_template_type', 'proactive'),
                subject_line=request.form['subject_line'],
                email_body=request.form['email_body'],
                is_active=True,
                created_at=datetime.utcnow(),
                delay_amount=int(request.form.get('delay_amount', 0)),
                delay_unit=request.form.get('delay_unit', 'days'),
                available_variables=json.loads(request.form.get('available_variables', '[]'))
            )
            
            db.session.add(template)
            db.session.commit()
            
            flash('Template created successfully!', 'success')
            return redirect(url_for('templates.templates'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error creating template: {str(e)}', 'error')
            print(f"Error creating template: {e}")
    
    return render_template('template_editor.html', template=None)

@templates_bp.route('/<int:template_id>/edit', methods=['GET', 'POST'])
def edit_template(template_id):
    """Edit existing email template"""
    template = EmailTemplate.query.get_or_404(template_id)
    
    if request.method == 'POST':
        try:
            sequence_order = request.form.get('sequence_order', 1)
            sequence_step = int(sequence_order) - 1
            
            template.name = request.form['name']
            template.template_type = request.form['template_type']
            template.risk_level = request.form['breach_status']
            template.sequence_step = sequence_step
            template.breach_template_type = request.form.get('breach_template_type', 'proactive')
            template.subject_line = request.form['subject_line']
            template.email_body = request.form['email_body']
            template.delay_amount = int(request.form.get('delay_amount', 0))
            template.delay_unit = request.form.get('delay_unit', 'days')
            template.available_variables = json.loads(request.form.get('available_variables', '[]'))
            template.updated_at = datetime.utcnow()
            
            db.session.commit()
            flash('Template updated successfully!', 'success')
            return redirect(url_for('templates.templates'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating template: {str(e)}', 'error')
    
    return render_template('template_editor.html', template=template)

@templates_bp.route('/<int:template_id>/preview')
def preview_template(template_id):
    """Preview email template"""
    template = EmailTemplate.query.get_or_404(template_id)
    
    # Sample data for preview
    sample_data = {
        'first_name': 'John',
        'last_name': 'Doe',
        'company': 'Acme Corp',
        'domain': 'acme.com',
        'title': 'IT Manager',
        'email': 'john.doe@acme.com'
    }
    
    return render_template('template_preview.html', 
                         template=template, 
                         sample_data=sample_data)

@templates_bp.route('/<int:template_id>/delete', methods=['POST'])
def delete_template(template_id):
    """Delete email template"""
    try:
        template = EmailTemplate.query.get_or_404(template_id)
        template_name = template.name

        # Check if template is being used in any emails
        from models.database import Email
        emails_using_template = Email.query.filter_by(template_id=template_id).count()

        if emails_using_template > 0:
            return jsonify({
                'success': False,
                'error': f'Cannot delete template "{template_name}" - it is being used by {emails_using_template} email(s)'
            })

        # Soft delete by setting active to False
        template.active = False
        template.updated_at = datetime.utcnow()
        db.session.commit()

        return jsonify({
            'success': True,
            'message': f'Template "{template_name}" deleted successfully'
        })

    except Exception as e:
        db.session.rollback()
        print(f"Error deleting template {template_id}: {e}")
        return jsonify({'success': False, 'error': str(e)})

@templates_bp.route('/api/<int:template_id>')
def get_template_api(template_id):
    """Get template data as JSON"""
    template = EmailTemplate.query.get_or_404(template_id)
    return jsonify(template.to_dict())

@templates_bp.route('/api/list')
def list_templates_api():
    """List all templates as JSON"""
    templates = EmailTemplate.query.filter_by(active=True).all()
    return jsonify([template.to_dict() for template in templates])

@templates_bp.route('/api/<int:template_id>/delete', methods=['POST'])
def delete_template_api(template_id):
    """Delete email template via API (returns JSON)"""
    try:
        template = EmailTemplate.query.get_or_404(template_id)
        template_name = template.name

        # Check if template is being used in any emails
        from models.database import Email
        emails_using_template = Email.query.filter_by(template_id=template_id).count()

        if emails_using_template > 0:
            return jsonify({
                'success': False,
                'error': f'Cannot delete template "{template_name}" - it is being used by {emails_using_template} email(s)'
            })

        # Soft delete by setting active to False
        template.active = False
        template.updated_at = datetime.utcnow()
        db.session.commit()

        return jsonify({
            'success': True,
            'message': f'Template "{template_name}" deleted successfully'
        })

    except Exception as e:
        db.session.rollback()
        print(f"Error deleting template {template_id}: {e}")
        return jsonify({'success': False, 'error': str(e)})

@templates_bp.route('/sequences/<int:sequence_id>/delete', methods=['POST'])
def delete_followup_sequence(sequence_id):
    """Delete followup sequence"""
    try:
        sequence = FollowUpSequence.query.get_or_404(sequence_id)
        sequence_name = sequence.name

        # Check if sequence is being used in any campaigns
        from models.database import Campaign
        campaigns_using_sequence = Campaign.query.filter_by(template_type=sequence.risk_level).count()

        if campaigns_using_sequence > 0:
            return jsonify({
                'success': False,
                'error': f'Cannot delete sequence "{sequence_name}" - it is being used by {campaigns_using_sequence} campaign(s)'
            })

        # Soft delete by setting active to False
        sequence.active = False
        sequence.updated_at = datetime.utcnow()
        db.session.commit()

        return jsonify({
            'success': True,
            'message': f'Follow-up sequence "{sequence_name}" deleted successfully'
        })

    except Exception as e:
        db.session.rollback()
        print(f"Error deleting followup sequence {sequence_id}: {e}")
        return jsonify({'success': False, 'error': str(e)})