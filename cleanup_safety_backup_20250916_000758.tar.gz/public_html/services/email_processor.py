"""
Email Processor Service - Handles email sending with all business rules
- Checks if contact has replied (stops sequence)
- Enforces daily email limits
- Schedules emails based on configurable delays
"""
import logging
from datetime import datetime, timedelta, date
from typing import Dict, List, Optional
from models.database import (
    db, Contact, Campaign, EmailSequence, ContactCampaignStatus,
    Email, EmailTemplate, FollowUpSequence
)
from services.email_service import create_email_service

logger = logging.getLogger(__name__)

class EmailProcessor:
    """Process scheduled emails with all business rules enforced"""
    
    def __init__(self):
        self.email_service = None
        self.daily_send_count = {}  # Track sends per campaign per day
        logger.info("Email Processor initialized")
    
    def process_scheduled_emails(self) -> Dict:
        """
        Main processing function - runs periodically to send scheduled emails
        Enforces all business rules:
        1. Checks if contact has replied (stops sequence)
        2. Respects daily limits per campaign
        3. Only sends emails scheduled for today or earlier
        """
        try:
            current_datetime = datetime.utcnow()
            today = date.today()
            results = {
                'emails_sent': 0,
                'emails_skipped': 0,
                'sequences_stopped': 0,
                'daily_limit_reached': []
            }
            
            # Get emails that are due now or overdue (no future window to prevent batch processing)
            # Only process emails scheduled for current time or earlier
            # STRICT TIMING: Add 30-second buffer to prevent early processing due to microsecond differences
            
            scheduled_emails = EmailSequence.query.filter(
                EmailSequence.status == 'scheduled'
            ).filter(
                # Use scheduled_datetime if available, otherwise fall back to scheduled_date
                (EmailSequence.scheduled_datetime.isnot(None) & 
                 (EmailSequence.scheduled_datetime <= current_datetime)) |
                (EmailSequence.scheduled_datetime.is_(None) & 
                 (EmailSequence.scheduled_date <= today))
            ).all()
            
            # ADDITIONAL FILTERING: Remove emails that are scheduled more than 30 seconds in the future
            # This prevents race conditions and ensures precise timing
            actually_ready_emails = []
            for email_seq in scheduled_emails:
                if email_seq.scheduled_datetime:
                    time_until_due = email_seq.scheduled_datetime - current_datetime
                    if time_until_due.total_seconds() <= 30:  # Allow 30-second early processing buffer
                        actually_ready_emails.append(email_seq)
                    else:
                        logger.info(f"TIMING: Email sequence {email_seq.id} not ready yet - {time_until_due} remaining")
                else:
                    # Date-based fallback (legacy)
                    actually_ready_emails.append(email_seq)
            
            scheduled_emails = actually_ready_emails
            
            logger.info(f"Found {len(scheduled_emails)} emails scheduled for processing")
            
            # DEBUG: Show summary of all scheduled emails with timing details
            if scheduled_emails:
                logger.info("=== EMAIL PROCESSING SUMMARY ===")
                for email_seq in scheduled_emails:
                    if email_seq.scheduled_datetime:
                        time_diff = email_seq.scheduled_datetime - current_datetime
                        timing_status = "READY" if time_diff.total_seconds() <= 0 else f"EARLY by {abs(time_diff)}"
                    else:
                        timing_status = "DATE-BASED"
                    logger.info(f"  Contact {email_seq.contact_id}, Campaign {email_seq.campaign_id}, Step {email_seq.sequence_step}, Scheduled: {email_seq.scheduled_datetime}, Status: {timing_status}")
                logger.info("================================")
            
            # Group by campaign for daily limit tracking
            campaigns_processed = {}
            
            for email_seq in scheduled_emails:
                campaign_id = email_seq.campaign_id
                contact_id = email_seq.contact_id
                
                # DEBUG LOGGING: Show which email is being processed
                logger.info(f"PROCESSING - Contact {contact_id}, Step {email_seq.sequence_step}, Scheduled: {email_seq.scheduled_datetime}, Now: {current_datetime}")
                
                # ATOMIC UPDATE: Claim this email sequence for processing
                # This prevents multiple workers from processing the same email
                try:
                    # Atomically update status from 'scheduled' to 'processing' 
                    # Only succeeds if status is still 'scheduled'
                    updated = db.session.execute(
                        db.text("""
                            UPDATE email_sequences 
                            SET status = 'processing'
                            WHERE id = :seq_id 
                            AND status = 'scheduled'
                            AND email_id IS NULL
                        """),
                        {'seq_id': email_seq.id}
                    )
                    db.session.commit()
                    
                    if updated.rowcount == 0:
                        logger.debug(f"EmailSequence {email_seq.id} already being processed, skipping")
                        results['emails_skipped'] += 1
                        continue
                        
                    # Refresh to get the updated record
                    db.session.refresh(email_seq)
                    
                except Exception as e:
                    logger.warning(f"Failed to claim EmailSequence {email_seq.id}: {str(e)}")
                    db.session.rollback()
                    continue
                
                # STRICT SEQUENCE DEPENDENCY CHECK: Ensure proper sequential progression
                
                # Check contact's current sequence step from ContactCampaignStatus
                contact_status = ContactCampaignStatus.query.filter_by(
                    contact_id=contact_id,
                    campaign_id=campaign_id
                ).first()
                
                current_step = contact_status.current_sequence_step if contact_status else 0
                logger.info(f"SEQUENCE CHECK - Contact {contact_id}: current_step={current_step}, attempting step={email_seq.sequence_step}")
                
                # Rule 1: Only send the next expected step (current_step should equal sequence_step)
                if email_seq.sequence_step != current_step:
                    logger.info(f"SEQUENCE BLOCK - Contact {contact_id} step {email_seq.sequence_step} is not the expected next step (current: {current_step})")
                    # Revert status back to scheduled for retry later
                    email_seq.status = 'scheduled'
                    db.session.commit()
                    results['emails_skipped'] += 1
                    continue
                
                # Rule 2: For follow-ups, verify previous EmailSequence is marked as sent
                if email_seq.sequence_step > 0:
                    previous_step = EmailSequence.query.filter_by(
                        contact_id=contact_id,
                        campaign_id=campaign_id,
                        sequence_step=email_seq.sequence_step - 1
                    ).first()
                    
                    prev_status = previous_step.status if previous_step else 'NOT_FOUND'
                    logger.info(f"DEPENDENCY CHECK - Contact {contact_id}, Step {email_seq.sequence_step}: Previous EmailSequence {email_seq.sequence_step - 1} status = '{prev_status}'")
                    
                    if not previous_step or previous_step.status != 'sent':
                        logger.info(f"DEPENDENCY BLOCK - Previous EmailSequence {email_seq.sequence_step - 1} not sent for contact {contact_id}")
                        # Revert status back to scheduled for retry later
                        email_seq.status = 'scheduled'
                        db.session.commit()
                        results['emails_skipped'] += 1
                        continue
                
                logger.info(f"DEPENDENCY PASS - Contact {contact_id} step {email_seq.sequence_step} is eligible for sending")
                
                # Get campaign and check daily limit
                campaign = Campaign.query.get(campaign_id)
                if not campaign:
                    logger.warning(f"Campaign {campaign_id} not found")
                    email_seq.status = 'failed'
                    email_seq.error_message = 'Campaign not found'
                    db.session.commit()
                    continue
                
                # Initialize daily counter for this campaign
                if campaign_id not in campaigns_processed:
                    campaigns_processed[campaign_id] = {
                        'sent_today': self._get_emails_sent_today(campaign_id),
                        'daily_limit': campaign.daily_limit or 50
                    }
                
                # Check if daily limit reached
                if campaigns_processed[campaign_id]['sent_today'] >= campaigns_processed[campaign_id]['daily_limit']:
                    logger.info(f"Daily limit reached for campaign {campaign.name}")
                    results['daily_limit_reached'].append(campaign.name)
                    # Revert to scheduled for tomorrow
                    email_seq.status = 'scheduled'
                    db.session.commit()
                    results['emails_skipped'] += 1
                    continue
                
                # Check if contact has replied (MOST IMPORTANT CHECK)
                should_send = self._should_send_to_contact(contact_id, campaign_id)
                
                if not should_send['send']:
                    logger.info(f"Skipping email to contact {contact_id}: {should_send['reason']}")
                    email_seq.status = 'skipped'
                    email_seq.skip_reason = should_send['reason']
                    db.session.commit()
                    
                    if should_send['reason'] == 'contact_replied':
                        results['sequences_stopped'] += 1
                    else:
                        results['emails_skipped'] += 1
                    continue
                
                # DEBUG: Log exact parameters before sending email
                logger.info(f"=== EMAIL SENDING DEBUG ===")
                logger.info(f"Campaign ID: {campaign_id}")
                logger.info(f"Contact ID: {contact_id}")
                logger.info(f"EmailSequence ID: {email_seq.id}")
                logger.info(f"Sequence Step from DB: {email_seq.sequence_step}")
                logger.info(f"Template Type from DB: '{email_seq.template_type}'")
                logger.info(f"Campaign Template ID: {campaign.template_id}")
                logger.info(f"========================")
                
                # Send the email
                send_result = self._send_email(email_seq, campaign)
                
                if send_result['success']:
                    email_seq.status = 'sent'
                    email_seq.sent_at = datetime.utcnow()
                    campaigns_processed[campaign_id]['sent_today'] += 1
                    results['emails_sent'] += 1
                    
                    # Update campaign sent count
                    campaign.sent_count = (campaign.sent_count or 0) + 1
                    
                    # No commit here - already committed in _send_email method
                else:
                    email_seq.status = 'failed'
                    email_seq.error_message = send_result.get('error', 'Unknown error')
                    results['emails_skipped'] += 1
                    
                    # Commit failed status
                    db.session.commit()
            
            db.session.commit()
            
            logger.info(f"Email processing complete: {results}")
            return results
            
        except Exception as e:
            logger.error(f"Error processing emails: {str(e)}")
            db.session.rollback()
            return {
                'error': str(e),
                'emails_sent': 0,
                'emails_skipped': 0
            }
    
    def _should_send_to_contact(self, contact_id: int, campaign_id: int) -> Dict:
        """
        Check if we should send email to this contact
        Returns dict with 'send' boolean and 'reason' if not sending
        """
        # Get contact and their campaign status
        contact = Contact.query.get(contact_id)
        if not contact:
            return {'send': False, 'reason': 'contact_not_found'}
        
        # Check if contact has unsubscribed
        if hasattr(contact, 'is_subscribed') and not contact.is_subscribed:
            return {'send': False, 'reason': 'contact_unsubscribed'}
        
        # Check if email bounced
        if hasattr(contact, 'email_status') and contact.email_status == 'bounced':
            return {'send': False, 'reason': 'email_bounced'}
        
        # Check if marked as spam
        if hasattr(contact, 'marked_as_spam') and contact.marked_as_spam:
            return {'send': False, 'reason': 'marked_as_spam'}
        
        # Get campaign status
        status = ContactCampaignStatus.query.filter_by(
            contact_id=contact_id,
            campaign_id=campaign_id
        ).first()
        
        if not status:
            return {'send': False, 'reason': 'no_campaign_status'}
        
        # CHECK IF CONTACT HAS REPLIED - THIS STOPS THE SEQUENCE
        if status.replied_at is not None:
            return {'send': False, 'reason': 'contact_replied'}
        
        # Check if sequence is already completed
        if status.sequence_completed_at is not None:
            return {'send': False, 'reason': 'sequence_completed'}
        
        # Check follow-up sequence settings
        campaign = Campaign.query.get(campaign_id)
        if campaign and campaign.template_id:
            template = EmailTemplate.query.get(campaign.template_id)
            if template and template.risk_level:
                # Check if sequence has stop_on_reply enabled
                sequence = FollowUpSequence.query.filter_by(
                    risk_level=template.risk_level
                ).first()
                
                if sequence and sequence.stop_on_reply:
                    # Double-check for any response
                    if hasattr(contact, 'has_responded') and contact.has_responded:
                        return {'send': False, 'reason': 'contact_responded'}
        
        return {'send': True, 'reason': None}
    
    def _get_emails_sent_today(self, campaign_id: int) -> int:
        """Get count of emails sent today for this campaign"""
        today_start = datetime.combine(date.today(), datetime.min.time())
        
        count = Email.query.filter(
            Email.campaign_id == campaign_id,
            Email.sent_at >= today_start
        ).count()
        
        return count
    
    def _send_email(self, email_seq: EmailSequence, campaign: Campaign) -> Dict:
        """Actually send the email using Brevo service"""
        try:
            # Get contact
            contact = Contact.query.get(email_seq.contact_id)
            if not contact:
                return {'success': False, 'error': 'Contact not found'}
            
            # Get template based on sequence step
            template = self._get_template_for_step(
                email_seq.sequence_step,
                email_seq.template_type,
                campaign
            )
            
            if not template:
                return {'success': False, 'error': 'No template found'}
            
            # Initialize email service if needed
            if not self.email_service:
                from models.database import Settings
                
                class EmailConfig:
                    BREVO_API_KEY = Settings.get_setting('brevo_api_key', '')
                    DEFAULT_SENDER_EMAIL = Settings.get_setting('sender_email', 'noreply@salesbreachpro.com')
                    DEFAULT_SENDER_NAME = Settings.get_setting('sender_name', 'SalesBreachPro')
                
                self.email_service = create_email_service(EmailConfig())
            
            # Prepare template variables
            template_vars = self._prepare_template_variables(contact, campaign)
            
            # Replace variables in subject and body
            subject = template.subject_line
            body = template.email_body
            
            for var, value in template_vars.items():
                subject = subject.replace('{' + var + '}', str(value))
                body = body.replace('{' + var + '}', str(value))
            
            # Determine email type based on sequence step
            email_type = 'initial' if email_seq.sequence_step == 0 else f'follow_up_{email_seq.sequence_step}'

            # Create Email record FIRST so we can pass email_id to Brevo service for message ID storage
            email_record = Email(
                contact_id=contact.id,
                campaign_id=campaign.id,
                template_id=template.id,
                email_type=email_type,
                subject=subject,
                body=body,
                content=body,  # Also populate content field
                status='pending'  # Initially pending
            )
            db.session.add(email_record)
            db.session.flush()  # Get the ID immediately

            # Get threading information for follow-up emails
            thread_message_id = None
            if email_seq.sequence_step > 0:
                # For follow-up emails, find the first email's thread_message_id
                first_email_seq = EmailSequence.query.filter_by(
                    contact_id=contact.id,
                    campaign_id=campaign.id,
                    sequence_step=0
                ).first()
                
                if first_email_seq and first_email_seq.email_id:
                    first_email = Email.query.get(first_email_seq.email_id)
                    if first_email and first_email.thread_message_id:
                        thread_message_id = first_email.thread_message_id
                        logger.info(f"Using thread Message-ID for follow-up: {thread_message_id}")

            # Send email via Brevo with email_id for message ID tracking
            success, result = self.email_service.send_single_email(
                to_email=contact.email,
                subject=subject,
                html_content=body,  # Will be converted to plain text by service
                text_content=body,  # Plain text version
                from_email=campaign.sender_email,
                from_name=campaign.sender_name,
                contact_id=contact.id,
                email_id=email_record.id,  # CRITICAL: Pass email_id for message ID storage
                thread_message_id=thread_message_id,  # For email threading
                sequence_step=email_seq.sequence_step  # For proper follow-up handling
            )

            if success:
                # Update Email record status (message ID already stored by send_single_email)
                email_record.status = 'sent'
                email_record.sent_at = datetime.utcnow()
                email_seq.email_id = email_record.id
                
                # CRITICAL: Commit immediately to prevent race condition duplicates
                db.session.commit()
                
                # Update contact last contacted
                if hasattr(contact, 'last_contacted_at'):
                    contact.last_contacted_at = datetime.utcnow()
                
                # CRITICAL: Update contact campaign status to track sequence progression
                status = ContactCampaignStatus.query.filter_by(
                    contact_id=contact.id,
                    campaign_id=campaign.id
                ).first()
                
                if status:
                    old_step = status.current_sequence_step
                    status.current_sequence_step = email_seq.sequence_step + 1
                    logger.info(f"STATE UPDATE - Contact {contact.id}: sequence step {old_step} -> {status.current_sequence_step}")
                    
                    # Commit the status update immediately
                    db.session.commit()
                else:
                    logger.warning(f"No ContactCampaignStatus found for contact {contact.id}, campaign {campaign.id}")
                
                return {'success': True, 'message_id': result}
            else:
                # Mark email record as failed
                email_record.status = 'failed'
                db.session.commit()
                return {'success': False, 'error': result}
                
        except Exception as e:
            logger.error(f"Error sending email: {str(e)}")
            return {'success': False, 'error': str(e)}
    
    def _get_template_for_step(self, step: int, template_type: str, campaign: Campaign) -> Optional[EmailTemplate]:
        """Get the appropriate template for this sequence step"""
        
        # DEBUG: Log template lookup parameters
        logger.info(f"=== TEMPLATE LOOKUP DEBUG ===")
        logger.info(f"Looking for: step={step}, template_type='{template_type}', campaign_id={campaign.id}")
        
        # Try to get template by sequence step and risk_level
        template = EmailTemplate.query.filter_by(
            sequence_step=step,
            risk_level=template_type,
            active=True
        ).first()
        
        if template:
            logger.info(f"PRIMARY SUCCESS: Found '{template.name}' (ID: {template.id})")
            logger.info(f"Template details: step={template.sequence_step}, risk_level='{template.risk_level}', active={template.active}")
            return template
        else:
            logger.info(f"PRIMARY FAILED: No template found for step={step}, risk_level='{template_type}'")
            
            # Debug what templates exist
            all_active = EmailTemplate.query.filter_by(active=True).all()
            logger.info(f"All active templates: {[(t.id, t.name, t.sequence_step, t.risk_level) for t in all_active]}")
            
            if campaign.template_id:
                # Fall back to campaign's default template
                fallback_template = EmailTemplate.query.get(campaign.template_id)
                if fallback_template:
                    logger.info(f"FALLBACK SUCCESS: Using campaign template '{fallback_template.name}' (ID: {fallback_template.id})")
                    return fallback_template
                else:
                    logger.info(f"FALLBACK FAILED: Campaign template {campaign.template_id} not found")
        
        logger.info(f"TEMPLATE LOOKUP FAILED: Returning None")
        return None
    
    def _prepare_template_variables(self, contact: Contact, campaign: Campaign) -> Dict:
        """Prepare all template variables for email"""
        variables = {
            'first_name': contact.first_name or 'there',
            'last_name': contact.last_name or '',
            'company': contact.company or 'your company',
            'email': contact.email,
            'domain': contact.email.split('@')[1] if '@' in contact.email else '',
            'campaign_name': campaign.name,
            'sender_name': campaign.sender_name or 'Security Team'
        }
        
        # Add breach sample if available
        status = ContactCampaignStatus.query.filter_by(
            contact_id=contact.id,
            campaign_id=campaign.id
        ).first()
        
        if status and status.breach_data:
            # Extract breach sample from breach data
            breach_samples = []
            if isinstance(status.breach_data, dict):
                samples = status.breach_data.get('samples', [])
                for sample in samples[:3]:  # Max 3 samples
                    breach_samples.append(f"• {sample}")
            
            if breach_samples:
                variables['breach_sample'] = "Sample exposed credentials:\\n" + "\\n".join(breach_samples)
            else:
                variables['breach_sample'] = "Sample exposed credentials:\\n• [Redacted for preview]"
        else:
            variables['breach_sample'] = ""
        
        return variables

# Global processor instance
email_processor = EmailProcessor()

def process_email_queue():
    """Function to be called by scheduler"""
    return email_processor.process_scheduled_emails()