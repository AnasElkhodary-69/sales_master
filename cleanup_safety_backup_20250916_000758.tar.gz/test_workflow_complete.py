#!/usr/bin/env python3
"""
Complete Workflow Test Script for SalesBreachPro
Tests the full flow: campaigns, contact upload, breach detection, and email sequences
Uses actual app functions to ensure real workflow testing
"""

import os
import sys
import time
from datetime import datetime, timedelta
import requests
import json

# Add the app directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import app components
from app import create_app
from models.database import db, Contact, Campaign, Email, EmailTemplate, FollowUpSequence
from services.intelligent_follow_up import IntelligentFollowUpService
from services.email_processor import EmailProcessor

def print_status(message, status="INFO"):
    """Print formatted status message"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{timestamp}] [{status}] {message}")

def test_app_initialization():
    """Test that the app initializes correctly"""
    print_status("=== Testing App Initialization ===")
    try:
        app = create_app()
        with app.app_context():
            # Test database connection
            campaigns = Campaign.query.all()
            print_status(f"App initialized successfully. Found {len(campaigns)} existing campaigns")
            return app
    except Exception as e:
        print_status(f"App initialization failed: {e}", "ERROR")
        return None

def create_test_campaigns(app):
    """Create two test campaigns: one for breached, one for non-breached"""
    print_status("=== Creating Test Campaigns ===")

    with app.app_context():
        try:
            # Create Breached Campaign
            breached_campaign = Campaign(
                name="Test Breached Campaign",
                description="Test campaign for breached emails with 5-min intervals",
                template_type="high_risk",
                target_risk_levels=["high", "medium"],
                daily_limit=50,
                status="active",
                sender_email="noreply@savety.online",
                sender_name="Security Alert System",
                created_at=datetime.utcnow()
            )

            # Create Non-Breached Campaign
            non_breached_campaign = Campaign(
                name="Test Non-Breached Campaign",
                description="Test campaign for non-breached emails with 5-min intervals",
                template_type="low_risk",
                target_risk_levels=["low"],
                daily_limit=50,
                status="active",
                sender_email="noreply@savety.online",
                sender_name="Security Update System",
                created_at=datetime.utcnow()
            )

            db.session.add(breached_campaign)
            db.session.add(non_breached_campaign)
            db.session.commit()

            print_status(f"Created breached campaign (ID: {breached_campaign.id})")
            print_status(f"Created non-breached campaign (ID: {non_breached_campaign.id})")

            return breached_campaign.id, non_breached_campaign.id

        except Exception as e:
            print_status(f"Failed to create campaigns: {e}", "ERROR")
            return None, None

def create_test_templates(app):
    """Create test email templates for the campaigns"""
    print_status("=== Creating Test Templates ===")

    with app.app_context():
        try:
            # Breached Email Template
            breached_template = EmailTemplate(
                name="Test Breached Template",
                subject_line="🚨 Security Alert: Your Email Found in Data Breach",
                email_body="""
Hi there,

We found your email address (info@moaz.ca) in a recent data breach. This is a test email to verify our breach notification system is working.

Test Details:
- Email: info@moaz.ca
- Campaign: Breached
- Time: {current_time}

This is a test message from SalesBreachPro workflow testing.

Best regards,
Test System
                """.strip(),
                template_type="breach_alert",
                risk_level="high",
                created_at=datetime.utcnow()
            )

            # Non-Breached Email Template
            non_breached_template = EmailTemplate(
                name="Test Non-Breached Template",
                subject_line="✅ Good News: Your Email is Secure",
                email_body="""
Hi there,

Great news! We checked your email address (info@moaz.ca) and it was NOT found in any recent data breaches.

Test Details:
- Email: info@moaz.ca
- Campaign: Non-Breached
- Time: {current_time}

This is a test message from SalesBreachPro workflow testing.

Best regards,
Test System
                """.strip(),
                template_type="security_update",
                risk_level="low",
                created_at=datetime.utcnow()
            )

            db.session.add(breached_template)
            db.session.add(non_breached_template)
            db.session.commit()

            print_status(f"Created breached template (ID: {breached_template.id})")
            print_status(f"Created non-breached template (ID: {non_breached_template.id})")

            return breached_template.id, non_breached_template.id

        except Exception as e:
            print_status(f"Failed to create templates: {e}", "ERROR")
            return None, None

def create_test_sequences(app, breached_campaign_id, non_breached_campaign_id, breached_template_id, non_breached_template_id):
    """Create follow-up sequences with 5-minute delays"""
    print_status("=== Creating Test Email Sequences ===")

    with app.app_context():
        try:
            # Breached sequence - 3 emails with 5-min intervals
            breached_sequence = FollowUpSequence(
                name="Breached Email Sequence",
                risk_level="high",
                template_type="high_risk",
                description="High-risk breach alert sequence with 5-minute intervals",
                max_follow_ups=3,
                steps=[
                    {
                        "step": 1,
                        "template_id": breached_template_id,
                        "delay_minutes": 0,
                        "subject": "🚨 Security Alert: Your Email Found in Data Breach"
                    },
                    {
                        "step": 2,
                        "template_id": breached_template_id,
                        "delay_minutes": 5,
                        "subject": "Follow-up: Urgent Security Action Required"
                    },
                    {
                        "step": 3,
                        "template_id": breached_template_id,
                        "delay_minutes": 10,
                        "subject": "Final Notice: Security Breach Detected"
                    }
                ],
                is_active=True
            )

            # Non-breached sequence - 2 emails with 5-min intervals
            non_breached_sequence = FollowUpSequence(
                name="Non-Breached Email Sequence",
                risk_level="low",
                template_type="low_risk",
                description="Low-risk security update sequence with 5-minute intervals",
                max_follow_ups=2,
                steps=[
                    {
                        "step": 1,
                        "template_id": non_breached_template_id,
                        "delay_minutes": 0,
                        "subject": "✅ Good News: Your Email is Secure"
                    },
                    {
                        "step": 2,
                        "template_id": non_breached_template_id,
                        "delay_minutes": 5,
                        "subject": "Security Update: Stay Protected"
                    }
                ],
                is_active=True
            )

            db.session.add(breached_sequence)
            db.session.add(non_breached_sequence)
            db.session.commit()

            print_status(f"Created breached sequence (ID: {breached_sequence.id}) with {len(breached_sequence.steps)} steps")
            print_status(f"Created non-breached sequence (ID: {non_breached_sequence.id}) with {len(non_breached_sequence.steps)} steps")

            return breached_sequence.id, non_breached_sequence.id

        except Exception as e:
            print_status(f"Failed to create sequences: {e}", "ERROR")
            return None, None

def upload_test_contact(app):
    """Upload the test contact info@moaz.ca"""
    print_status("=== Uploading Test Contact ===")

    with app.app_context():
        try:
            # Check if contact already exists
            existing_contact = Contact.query.filter_by(email="info@moaz.ca").first()
            if existing_contact:
                print_status("Contact info@moaz.ca already exists, deleting and recreating")
                db.session.delete(existing_contact)
                db.session.commit()

            # Create new contact
            test_contact = Contact(
                email="info@moaz.ca",
                domain="moaz.ca",
                first_name="Test",
                last_name="User",
                company="Test Company",
                breach_status="unknown",  # Will be determined by breach check
                created_at=datetime.utcnow()
            )

            db.session.add(test_contact)
            db.session.commit()

            print_status(f"Uploaded test contact: info@moaz.ca (ID: {test_contact.id})")
            return test_contact.id

        except Exception as e:
            print_status(f"Failed to upload contact: {e}", "ERROR")
            return None

def simulate_breach_check(app, contact_id):
    """Simulate breach detection for the test contact"""
    print_status("=== Simulating Breach Check ===")

    with app.app_context():
        try:
            contact = Contact.query.get(contact_id)
            if not contact:
                print_status("Contact not found", "ERROR")
                return False

            # For testing, let's say info@moaz.ca is breached
            # In real scenario this would call the breach detection API
            contact.breach_status = "breached"
            contact.breach_count = 2
            contact.last_breach_date = datetime.utcnow() - timedelta(days=30)
            contact.breach_details = "Test breach data - LinkedIn (2021), Adobe (2019)"

            db.session.commit()

            print_status(f"Contact marked as BREACHED with 2 breaches")
            print_status(f"Breach details: {contact.breach_details}")

            return True

        except Exception as e:
            print_status(f"Failed to simulate breach check: {e}", "ERROR")
            return False

def trigger_campaign_enrollment(app, contact_id, breached_campaign_id, non_breached_campaign_id):
    """Trigger campaign enrollment based on breach status"""
    print_status("=== Triggering Campaign Enrollment ===")

    with app.app_context():
        try:
            contact = Contact.query.get(contact_id)
            if not contact:
                print_status("Contact not found", "ERROR")
                return False

            # Determine which campaign to enroll in
            if contact.breach_status == "breached":
                campaign_id = breached_campaign_id
                campaign_type = "BREACHED"
            else:
                campaign_id = non_breached_campaign_id
                campaign_type = "NON-BREACHED"

            # Use IntelligentFollowUpService to enroll contact
            followup_service = IntelligentFollowUpService()

            # Get the campaign
            campaign = Campaign.query.get(campaign_id)
            if not campaign:
                print_status(f"Campaign {campaign_id} not found", "ERROR")
                return False

            # Enroll contact in campaign
            success = followup_service.enroll_contact_in_campaign(contact, campaign)

            if success:
                print_status(f"Successfully enrolled contact in {campaign_type} campaign")
                return True
            else:
                print_status(f"Failed to enroll contact in {campaign_type} campaign", "ERROR")
                return False

        except Exception as e:
            print_status(f"Failed to trigger campaign enrollment: {e}", "ERROR")
            return False

def monitor_email_processing(app, duration_minutes=20):
    """Monitor the email processing for the specified duration"""
    print_status(f"=== Monitoring Email Processing for {duration_minutes} minutes ===")

    start_time = datetime.now()
    end_time = start_time + timedelta(minutes=duration_minutes)

    with app.app_context():
        try:
            # Get initial email count
            initial_count = Email.query.count()
            print_status(f"Initial email count: {initial_count}")

            # Initialize email processor
            email_processor = EmailProcessor()

            check_interval = 30  # Check every 30 seconds

            while datetime.now() < end_time:
                current_time = datetime.now()
                elapsed = (current_time - start_time).total_seconds() / 60

                print_status(f"Elapsed time: {elapsed:.1f} minutes")

                # Process emails
                try:
                    results = email_processor.process_scheduled_emails()
                    if results['emails_sent'] > 0:
                        print_status(f"✅ Processed {results['emails_sent']} emails")

                        # Show email details
                        recent_emails = Email.query.filter(
                            Email.created_at >= start_time
                        ).order_by(Email.created_at.desc()).limit(10).all()

                        for email in recent_emails:
                            status_emoji = "📧" if email.status == "scheduled" else "✅" if email.status == "sent" else "❌"
                            print_status(f"  {status_emoji} Email to {email.contact.email} - Status: {email.status}")

                except Exception as e:
                    print_status(f"Email processing error: {e}", "ERROR")

                # Current email count
                current_count = Email.query.count()
                new_emails = current_count - initial_count
                print_status(f"Total emails created: {new_emails}")

                # Wait before next check
                print_status(f"Waiting {check_interval} seconds before next check...")
                time.sleep(check_interval)

            print_status("=== Monitoring Complete ===")

            # Final summary
            final_count = Email.query.count()
            total_created = final_count - initial_count

            sent_emails = Email.query.filter(
                Email.created_at >= start_time,
                Email.status == 'sent'
            ).count()

            print_status(f"📊 FINAL SUMMARY:")
            print_status(f"  📧 Total emails created: {total_created}")
            print_status(f"  ✅ Total emails sent: {sent_emails}")
            print_status(f"  ⏰ Monitoring duration: {duration_minutes} minutes")

        except Exception as e:
            print_status(f"Monitoring error: {e}", "ERROR")

def run_complete_workflow_test():
    """Run the complete workflow test"""
    print_status("🚀 STARTING COMPLETE WORKFLOW TEST")
    print_status("=" * 60)

    # Step 1: Initialize app
    app = test_app_initialization()
    if not app:
        print_status("❌ Test failed at app initialization", "ERROR")
        return

    # Step 2: Create campaigns
    breached_campaign_id, non_breached_campaign_id = create_test_campaigns(app)
    if not breached_campaign_id or not non_breached_campaign_id:
        print_status("❌ Test failed at campaign creation", "ERROR")
        return

    # Step 3: Create templates
    breached_template_id, non_breached_template_id = create_test_templates(app)
    if not breached_template_id or not non_breached_template_id:
        print_status("❌ Test failed at template creation", "ERROR")
        return

    # Step 4: Create sequences
    breached_sequence_id, non_breached_sequence_id = create_test_sequences(app, breached_campaign_id, non_breached_campaign_id, breached_template_id, non_breached_template_id)
    if not breached_sequence_id or not non_breached_sequence_id:
        print_status("❌ Test failed at sequence creation", "ERROR")
        return

    # Step 5: Upload contact
    contact_id = upload_test_contact(app)
    if not contact_id:
        print_status("❌ Test failed at contact upload", "ERROR")
        return

    # Step 6: Simulate breach check
    if not simulate_breach_check(app, contact_id):
        print_status("❌ Test failed at breach check", "ERROR")
        return

    # Step 7: Trigger campaign enrollment
    if not trigger_campaign_enrollment(app, contact_id, breached_campaign_id, non_breached_campaign_id):
        print_status("❌ Test failed at campaign enrollment", "ERROR")
        return

    # Step 8: Monitor email processing
    print_status("🔄 Starting email sequence monitoring...")
    print_status("Expected: 3 emails with 5-minute intervals for breached contact")
    monitor_email_processing(app, duration_minutes=20)

    print_status("✅ WORKFLOW TEST COMPLETED")
    print_status("=" * 60)
    print_status("Check your email (if configured) or the database for sent emails")

if __name__ == "__main__":
    run_complete_workflow_test()