#!/usr/bin/env python3
"""
Create working email sequence using the actual app models
This uses the EmailSequence model which is designed for scheduled emails
"""

import os
import sys
from datetime import datetime, timedelta

# Add the app directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from models.database import db, Contact, Campaign, Email, EmailTemplate, FollowUpSequence, EmailSequence

def create_working_email_sequence():
    """Create working email sequence for the test contact using EmailSequence model"""
    print("=" * 60)
    print("CREATING WORKING EMAIL SEQUENCE")
    print("=" * 60)

    app = create_app()
    with app.app_context():
        # Get the contact
        contact = Contact.query.filter_by(email="info@moaz.ca").first()
        if not contact:
            print("❌ Contact info@moaz.ca not found!")
            return

        print(f"✅ Found contact: {contact.email} (Status: {contact.breach_status})")

        # Get the appropriate campaign based on breach status
        if contact.breach_status == "breached":
            campaign = Campaign.query.filter_by(template_type="high_risk").first()
            print("🚨 Using BREACHED campaign workflow")
        else:
            campaign = Campaign.query.filter_by(template_type="low_risk").first()
            print("✅ Using NON-BREACHED campaign workflow")

        if not campaign:
            print("❌ No appropriate campaign found!")
            return

        print(f"✅ Found campaign: {campaign.name} (ID: {campaign.id})")

        # Get sequence definition
        if contact.breach_status == "breached":
            sequence = FollowUpSequence.query.filter_by(risk_level="high").first()
        else:
            sequence = FollowUpSequence.query.filter_by(risk_level="low").first()

        if not sequence:
            print("❌ No sequence found!")
            return

        print(f"✅ Found sequence: {sequence.name} with {len(sequence.steps)} steps")

        # Create EmailSequence records for each step
        base_time = datetime.utcnow()
        created_sequences = []

        for step_data in sequence.steps:
            step_num = step_data.get('step', 1)
            delay_minutes = step_data.get('delay_minutes', 0)

            # Calculate when this email should be sent
            scheduled_datetime = base_time + timedelta(minutes=delay_minutes)

            # Check if sequence already exists
            existing = EmailSequence.query.filter_by(
                contact_id=contact.id,
                campaign_id=campaign.id,
                sequence_step=step_num
            ).first()

            if existing:
                print(f"⚠️  Step {step_num} already exists, skipping")
                continue

            # Create the EmailSequence record
            email_sequence = EmailSequence(
                contact_id=contact.id,
                campaign_id=campaign.id,
                sequence_step=step_num,
                template_type="breached" if contact.breach_status == "breached" else "proactive",
                scheduled_date=scheduled_datetime.date(),
                scheduled_datetime=scheduled_datetime,
                status='scheduled',
                created_at=datetime.utcnow()
            )

            db.session.add(email_sequence)
            created_sequences.append(email_sequence)

            print(f"📧 Created sequence step {step_num}: scheduled for {scheduled_datetime} ({delay_minutes} min delay)")

        # Commit all sequences
        db.session.commit()

        print(f"\n✅ Successfully created {len(created_sequences)} email sequence steps!")

        # Show the complete schedule
        print("\n📅 COMPLETE EMAIL SEQUENCE SCHEDULE:")
        all_sequences = EmailSequence.query.filter_by(
            contact_id=contact.id,
            campaign_id=campaign.id
        ).order_by(EmailSequence.sequence_step).all()

        for seq in all_sequences:
            status_icon = "⏰" if seq.status == "scheduled" else "✅" if seq.status == "sent" else "❌"
            print(f"  {status_icon} Step {seq.sequence_step}: {seq.scheduled_datetime} - Status: {seq.status}")

        print(f"\n🎯 Contact {contact.email} enrolled in {campaign.name}")
        print("📧 Emails will be processed by the email processor service")

        return True

if __name__ == "__main__":
    create_working_email_sequence()